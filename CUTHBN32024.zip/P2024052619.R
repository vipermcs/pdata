# P2024052619.R MCNut24.R 2024-May-26 vipermcs@gmail.com et al 2021-Mar-08 
# ------------------------------------------------------------------------------------------------------------------------ #
# Basic Packages
require(tidyverse)
windows(width=6,height=6,record=TRUE)
options(digits=5,width=240)
options(survey.lonely.psu="adjust")
options(dplyr.summarise.inform=FALSE,dplyr.show_progress=FALSE)
# ------------------------------------------------------------------------------------------------------------------------ #
# Parameters
PCRIT = 0.05
ZCRIT = qnorm(1-PCRIT/2)
ALPHA = PCRIT
DWORK = "Z:\\"			# working folder
DTABS = "X:\\Tabs\\"	# reference folder, can be DTABS="Z:\\"
setwd(DWORK)
RRSEED=prod(as.numeric(unlist(strsplit("197 174 118","\\s+"))))	# https://www.random.org/cgi-bin/randbyte?nbytes=4&format=d 2023-Mat-02 19:52 219
NCORES=parallel::detectCores() 
# ------------------------------------------------------------------------------------------------------------------------ #
# Documentation
# Software for the paper
# "New WHO guideline on the definition of anemia: 
# implications for 6-35 months old children in Peru 2009-2023"
# Miguel Campos, Luis Cordero, Enrique Velásquez, Nelly Baiocchi, 
# Marianella Miranda, María Inés Sánchez-Griñán, Walter Valdivia.
# This code has three parts:
#   I Consolidado ENDES
#     Provided here only as documentation, it will not necessarily execute.
#     Generates N44, a consolidated data frame of ENDES 2009-2023 children.
#     It is used for several purposes in our group.
#     It depends on downloaded ENDES ZIPs in folders for each year,
#     and a table listing files and years for ENDES (in PETabs.rda).
#  II Preparación de Datos
#     Provided here only as documentation, it will not necessarily execute.
#     Generates d, a data frame (tibble), summarized subset of N44.
#     It is used only for analysis in this paper.
# III Artículo
#     It can be executed together with the d data frame.
#     It requires R and the tidyverse & survey packages.
#     It has two sections:
#     - Generation of Weighed Estimates (it can take a while)
#     - Production of Graphs 
# ------------------------------------------------------------------------------------------------------------------------ #
# I Consolidado ENDES
if(FALSE){	# endes
# load(paste(DTABS,"NuTabs.rda",sep=""))
# load(paste(DTABS,"GCTabs.rda",sep=""))
load(paste(DTABS,"PETabs.rda",sep=""))
print(date())
# Desempaquetado Provisional
DTABw=tempdir()	# DTABS
dir.create(path=paste0(DTABw,"/","ENDES"))
for(s in unique(TENDESF$SrcYear)){
	dir.create(path=paste0(DTABw,"/ENDES/",s))
}
for(s in c("RECH0","RECH23","REC21","REC41","REC42","REC43","REC44","REC95")){
	y=TENDESF%>%filter(grepl(paste0(s,"."),toupper(SrcFile)))
	for(i in 1:nrow(y)){
		unzip(
			zipfile=paste0(y$SrcPath[i],"/",y$SrcYear[i],"/",y$ZipFile[i]),
			files=y$Name[i],
			exdir=paste0(DTABw,"/ENDES/",y$SrcYear[i],"/"),
			junkpaths=TRUE
		)
	}
}
for(p in c("S2023")){
	r=paste0(DTABw,"ENDES/",p,"/")
	l=dir(r)
	for(k in 1:length(l)){
		file.rename(
			from=paste0(r,l[k]),
			to=paste0(r,gsub(paste0("_",substr(p,2,5)),"",l[k]))
		)
	}
}
DTABw=paste0(DTABw,"/")
print(date())
# Procesamiento Individualizado
rENDESy=function(yy){
	s=paste0(DTABw,"ENDES\\S",yy,"\\")
	H00=haven::read_sav(file=paste0(s,"RECH0.SAV"))
	if(yy==2014){H00=H00%>%rename(HV005=hv005)}
	if(yy==2016){H00=H00%>%rename(HV005=hv005,HV022=hv022)}
	if(yy>2017){H00=H00%>%mutate(HV016=as.numeric(NA))}
	if(yy==2018){H00=H00%>%mutate(HV007=yy)}
	H03=haven::read_sav(file=paste0(s,"RECH23.SAV"))
	if(yy==2005){
		H03=
			H03%>%
			rename(HHID=hhid,SHREGION=shregion)%>%
			mutate(SHPROVIN=NA,SHDISTRI=NA)
	}
	H03=H03%>%select(one_of("HHID","SHREGION","SHPROVIN","SHDISTRI"))
	R21=
		haven::read_sav(file=paste0(s,"REC21.SAV"))%>%
		rename(HWIDX=BIDX)%>%
		select(one_of("CASEID","HWIDX","B1","B2","B4","B8","B9","B16"))
	if(!yy%in%c(2000,2005)){	# tienen 41 y 42
		R41=
			haven::read_sav(file=paste0(s,"REC41.SAV"))%>%
			mutate(HHID=substr(CASEID,1,15))%>%
			rename(HWIDX=MIDX)%>%
			select(one_of("CASEID","HWIDX","M39"))
		R42=
			haven::read_sav(file=paste0(s,"REC42.SAV"))%>%
			mutate(HHID=substr(CASEID,1,15))%>%
			select(
				CASEID,
				V404,V409,V409A,V410,V410A,V411,V411A,
				V412,V412A,V412B,V413,V413A,V413B,V413C,V413D,
				V414A,V414B,V414C,V414D,V414E,V414F,V414G,V414H,
				V414I,V414J,V414K,V414L,V414M,V414N,V414O,V414P,
				V414Q,V414R,V414S,V414T,V414U
			)
	}					# tienen 41 y 42
	R43=
		haven::read_sav(file=paste0(s,"REC43.SAV"))%>%
		rename(HWIDX=HIDX)%>%
		select(CASEID,HWIDX,H11)
	R44=haven::read_sav(file=paste0(s,"REC44.SAV"))
	if(yy>=2012){	# longitud de CASEID
		R44=R44%>%mutate(HHID=substr(CASEID,1,15))
	}else{
		R44=R44%>%mutate(HHID=substr(CASEID,1,12))
	}
	if(!yy%in%c(2000,2005)){	# tienen R95
		R95=
			haven::read_sav(file=paste0(s,"REC95.SAV"))
		if(yy%in%c(2007,2008,2009:2012)){
			R95=R95%>%mutate(S465EA=NA,S465EB=NA,S465EC=NA,S465ED=NA)
		}
		if(yy%in%c(2009)){
			R95=
				R95%>%
				rename(
					S476AN1=S482BDN1,
					S476AS1=S482BDS1,
					S476AT1=S482BDT1,
					S476AR1=S482BDR1,
					S476AN2=S482BDN2,
					S476AS2=S482BDS2,
					S476AT2=S482BDT2,
					S476AR2=S482BDR2,
					S476AN3=S482BDN3,
					S476AS3=S482BDS3,
					S476AT3=S482BDT3,
					S476AR3=S482BDR3,
					S476AN4=S482BDN4,
					S476AS4=S482BDS4,
					S476AT4=S482BDT4,
					S476AR4=S482BDR4,
					S476AN5=S482BDN5,
					S476AS5=S482BDS5,
					S476AT5=S482BDT5,
					S476AR5=S482BDR5,
					S476AN6=S482BDN6,
					S476AS6=S482BDS6,
					S476AT6=S482BDT6,
					S476AR6=S482BDR6,
					S476AN7=S482BDN7,
					S476AS7=S482BDS7,
					S476AT7=S482BDT7,
					S476AR7=S482BDR7
				)
		}else if(yy%in%c(2007,2008)){
			R95=
				R95%>%
				mutate(
					S476AN1=as.numeric(NA),
					S476AS1=as.numeric(NA),
					S476AT1=as.numeric(NA),
					S476AR1=as.numeric(NA),
					S476AN2=as.numeric(NA),
					S476AS2=as.numeric(NA),
					S476AT2=as.numeric(NA),
					S476AR2=as.numeric(NA),
					S476AN3=as.numeric(NA),
					S476AS3=as.numeric(NA),
					S476AT3=as.numeric(NA),
					S476AR3=as.numeric(NA),
					S476AN4=as.numeric(NA),
					S476AS4=as.numeric(NA),
					S476AT4=as.numeric(NA),
					S476AR4=as.numeric(NA),
					S476AN5=as.numeric(NA),
					S476AS5=as.numeric(NA),
					S476AT5=as.numeric(NA),
					S476AR5=as.numeric(NA),
					S476AN6=as.numeric(NA),
					S476AS6=as.numeric(NA),
					S476AT6=as.numeric(NA),
					S476AR6=as.numeric(NA),
					S476AN7=as.numeric(NA),
					S476AS7=as.numeric(NA),
					S476AT7=as.numeric(NA),
					S476AR7=as.numeric(NA)
				)
		}
		R95=R95%>%rename(HWIDX=IDX95)
		if(yy%in%c(2009:2012)){
			R95=
				R95%>%
				select(
					CASEID,HWIDX,
					S465EA,S465EB,S465EC,S465ED,S466:S466C,
					S476AN1:S476AR7,S45RT1:S45RT2Y
				)
		}else if(yy%in%c(2007,2008)){
			R95=
				R95%>%
				select(
					CASEID,HWIDX,
					S465EA,S465EB,S465EC,S465ED,S466:S466C,
					S476AN1:S476AR7
				)
		}
	}					# tienen R95
	h00=
		H00%>%
		mutate(
			HHID=as.character(HHID),
			W1R=HV005/1E6,
			SID=HV022*100+HV023
		)%>%
		mutate(
			VV007=yy,
			VV006=HV008-12*(HV007-1900)
		)%>%
		select(one_of(c(
			"HHID","W1R","SID",
			"HV001","HV022","HV023","HV025","HV026",
			"HV007","VV006","VV007","HV016","HV040"
		)))%>%	# ,"HV024","HV015","HV042"
		left_join(y=H03,by=(c("HHID")))
	rXX=R44
	if(!yy%in%c(2000,2005)){
		r42=
			R42%>%
			left_join(
				y=
					R21%>%
					filter(B9==0)%>%
					group_by(CASEID)%>%
					summarize(B8=min(B8,na.rm=TRUE))%>%
					left_join(
						y=
							R21%>%
							filter(B9==0)%>%
							select(CASEID,B8,B16,HWIDX),
						by=c("CASEID","B8"))%>%
					group_by(CASEID)%>%
					summarize(HWIDX=head(HWIDX,1)),
				by=c("CASEID")
			)
		rXX=
			rXX%>%
			left_join(h00,by=c("HHID"))%>%
			left_join(R95,by=c("CASEID","HWIDX"))%>%
			left_join(R21,by=c("CASEID","HWIDX"))%>%
			left_join(R41,by=c("CASEID","HWIDX"))%>%
			left_join(r42,by=c("CASEID","HWIDX"))%>%
			left_join(R43,by=c("CASEID","HWIDX"))
		if(yy%in%c(2004:2008)){rXX=rXX%>%filter(HV007==VV007)}
		L=
			list(
				H00=H00,H03=H03,
				R21=R21,
				R41=R41,R42=R42,R43=R43,R44=R44,
				R95=R95,
				h00=h00,r42=r42,rXX=rXX
			)
	}
	if(yy%in%c(2000,2005)){
		rXX=
			rXX%>%
			left_join(h00,by=c("HHID"))%>%
			mutate(S465EA=NA,S465EB=NA,S465EC=NA,S465ED=NA)%>%
			left_join(R21,by=c("CASEID","HWIDX"))%>%
			left_join(R43,by=c("CASEID","HWIDX"))
		if(yy%in%c(2004:2008)){rXX=rXX%>%filter(HV007==VV007)}
		L=
			list(
				H00=H00,H03=H03,
				R21=R21,
				R43=R43,R44=R44,
				h00=h00,rXX=rXX
			)
	}
	#rXX=rXX%>%mutate(HV007=yy)
	return(L)
# del 22 al 18, por lo menos, son iguales, resto parecidos
}
# Ciclo 2021-2023
r=rENDESy(yy=2023);r4423=r$rXX
r=rENDESy(yy=2022);r4422=r$rXX
r=rENDESy(yy=2021);r4421=r$rXX
# Ciclo 2018-2020
r=rENDESy(yy=2020);r4420=r$rXX
r=rENDESy(yy=2019);r4419=r$rXX
r=rENDESy(yy=2018);r4418=r$rXX
# Ciclo 2015-2017
r=rENDESy(yy=2017);r4417=r$rXX
r=rENDESy(yy=2016);r4416=r$rXX
r=rENDESy(yy=2015);r4415=r$rXX
# Ciclo 2012-2014
r=rENDESy(yy=2014);r4414=r$rXX
r=rENDESy(yy=2013);r4413=r$rXX
r=rENDESy(yy=2012);r4412=r$rXX
# Ciclo 2009-2011
r=rENDESy(yy=2011);r4411=r$rXX
r=rENDESy(yy=2010);r4410=r$rXX
r=rENDESy(yy=2009);r4409=r$rXX
# Ciclo 2004-2008
r=rENDESy(yy=2008);r4408=r$rXX
r=rENDESy(yy=2007);r4407=r$rXX
r=rENDESy(yy=2005);r4405=r$rXX
# Años Anteriores
r=rENDESy(yy=2000);r4400=r$rXX
# Consolidación
N44=
	bind_rows(
		r4423,r4422,r4421,
		r4420,r4419,r4418,
		r4417,r4416,r4415,
		r4414,r4413,r4412,
		r4411,r4410,r4409,
		r4408,r4407,r4405,r4400
	)
N44=
	N44%>%
	mutate(
		FEnt=as.Date(paste(VV006,"/",HV016,"/",HV007,sep=""),"%m/%d/%Y"),	# está en FENT
		FNac=as.Date(paste(B1,"/15/",B2,sep=""),"%m/%d/%Y")
	)%>%
	mutate(
		EdadM=ifelse(HV007%in%c(2018),HW1,as.numeric(FEnt-FNac)/30.4375),
		IDTE=ifelse(is.na(HW70),NA,ifelse(HW70>6000,NA,ifelse(HW70<(-200),1,0))),
		IDPT=ifelse(is.na(HW72),NA,ifelse(HW72>6000,NA,ifelse(HW72<(-200),1,0))),
		ISPO=ifelse(is.na(HW70),NA,ifelse(HW70>6000,NA,ifelse(HW70>200,1,0))),
		ISF7=ifelse(is.na(S465EA)&is.na(S465EB)&is.na(S465EC)&is.na(S465ED),NA,ifelse(S465EA==1|S465EB==1|S465EC==1|S465ED==1,1,0)),
		HW56=ifelse(HW56<20|HW56>400,NA,HW56),
		IANE=ifelse(is.na(HW56),NA,ifelse(HW56<110,1,0)),
		GA12=12*as.integer(HW1/12)+6
	)%>%
	mutate(
		GEDA=as.integer(HW1/ifelse(HW1<6,3,ifelse(HW1<12,6,12)))*ifelse(HW1<6,3,ifelse(HW1<12,6,12))+ifelse(HW1<6,3,ifelse(HW1<12,6,12))/2,
		FENT=ISOdate(HV007,VV006,HV016)
	)
# Ponderación Conjunta
x=TPPBE17%>%filter(EDADS%in%0:2)%>%select(EDADS,A2000,A2003:A2007,A2008,A2009:A2023)
y=(x[1,-1]/2+x[2,-1]+x[3,-1])
z=N44%>%group_by(VV007)%>%summarize(TW1R=sum(W1R,na.rm=TRUE))
u=unlist(sapply(1:nrow(N44),function(i){(N44$W1R[i]/z$TW1R[z$VV007==N44$VV007[i]])*y[1,paste0("A",as.character(N44$VV007[i]))]}))
N44$W1RP=u
Q44=survey::svydesign(ids=~HV001+CASEID,weights=~W1RP,strata=~SID,data=subset(N44,!is.na(W1RP)&W1RP>0),nest=TRUE)
save(N44,Q44,file="ENDESV20.rda")
print(date())
}			# endes
# ------------------------------------------------------------------------------------------------------------------------ #
# II Preparación de Datos
if(FALSE){	# load
load(file="X:/Work/ENDESV20.rda")	# consolidado (ENDEStxx.R, PETabs.R)
print(date())
# re-cálculo en ENDES, adaptado de MSG1808.R (para CHANE)
d=
	N44%>%
	filter(HV007>2008&!is.na(IANE)&!is.na(HW1)&HW1>=6&HW1<36)%>%
	mutate(
		HVGR6=ifelse(SHREGION==1,1,ifelse(HV040>=3000,4,HV025+ifelse(SHREGION==4,4,1))),
		HV0YM=HV007+0.5/12+(VV006-1)/12,
		FPM=ifelse(HV007<2014,1,ifelse(HV007<2015,2,3)),
		AAS=(0.0048108*HV040)+(0.0000004*HV040^2),			# Sharma 2019
		AAW=((-0.032*(HV040*0.0032808)+0.022*(HV040*0.0032808)^2)*10),	# CDC 1989, WHO 2011
		A24=(0.0056384*HV040)+(0.0000003*HV040^2),			# WHO 2024, continuous
		AS4=c(0,4,8,11,14,18,21,25,29,33)[(ifelse(HV040>=5000,4999,HV040)%/%500)+1],			# WHO 2024, staircase
		SID2=HV023*10+HV025
	)%>%
	mutate(
		IANE2=ifelse(is.na(HW56),NA,ifelse(HW56<100,1,0)),
		IANE3=ifelse(is.na(HW56),NA,ifelse((HW53-AAW)<110,1,0)),
		IANE5=ifelse(is.na(HW56),NA,ifelse((HW53-AAS)<10*(9.8+HW1/30),1,0)),
		IANE4=ifelse(is.na(HW56),NA,ifelse((HW53-A24)<ifelse(HW1<24,105,110),1,0)),
		IANE6=ifelse(is.na(HW56),NA,ifelse((HW53-AS4)<ifelse(HW1<24,105,110),1,0)),
		HVLYM=log(HV0YM),
		FAGR6=factor(x=HVGR6,labels=c("Lima","C y S Urb <3Km","C y S Rur <3Km","Sierra 3+ Km","Selva Urb","Selva Rur")),
		FEDA6=factor(x=6*as.integer(HW1/6),labels=c("6-11m","12-17m","18-23m","24-29m","30-35m")),
		FALT9=factor(x=0.5*as.integer(ifelse(HV040>4500,4500,HV040)/500)),
		FEDA3=factor(x=12*as.integer(HW1/12),labels=c("6-11m","12-23m","24-35m")),
		FALT3=factor(x=ifelse(HV040<1000,0,ifelse(HV040<3000,2000,3500)),labels=c("0-0.9km","1-2.9km","3+km")),
		FY1=ifelse(FPM==1,0,1),
		FY2=ifelse(FPM==3,1,0)
	)%>%
	select(
		HV007,VV007,VV006,HV0YM,HVLYM,HW1,B4,IANE,HW56,HW53,
		AAW,AAS,A24,AS4,IANE2,IANE3,IANE5,IANE4,IANE6,HVGR6,
		FAGR6,FEDA6,FALT9,FEDA3,FALT3,FPM,FY1,FY2,
		HV001,HV023,HV025,HV026,HV040,SHREGION,CASEID,W1RP,SID,SID2
	)%>%
	labelled::set_variable_labels(
		HV007	="año de encuesta (real)",
		VV007	="año de encuesta (nominal)",
		VV006	="mes de encuesta",
		HV0YM	="mes y fracción de encuesta",
		HVLYM	="log natural del mes y fracción",
		HW1 	="edad, meses cumplidos",
		B4  	="sexo",
		IANE	="anemia (DHS)",
		HW56	="hb corregida (DHS)",
		HW53	="hb sin corregir",
		AAW 	="ajuste WHO 2011",
		AAS 	="ajuste Sharma 2019",
		A24 	="ajuste WHO 2024, continuo",
		AS4 	="ajuste WHO 2024, escalera",
		IANE2	="anemia (10)",
		IANE3	="anemia (WHO 2001)",
		IANE5	="anemia (Sharma, edad ad hoc)",
		IANE4	="anemia (WHO 2024, continua)",
		IANE6	="anemia (WHO 2024, escalera)",
		HVGR6	="zona ecológica (6)",
		FAGR6	="zona ecoaltura (6)",
		FEDA6	="edad (semestres)",
		FALT9	="altitud (500m 9)",
		FEDA3	="edad (años)",
		FALT3	="altitud (3)",
		FPM 	="ciclo ENDES",
		FY1 	="ciclo ENDES 1",
		FY2 	="ciclo ENDES 2",
		HV040	="altitud m snm",
		CASEID	="id sujeto",
		W1RP	="ponderación, reescalada",
		SID 	="estrato: HV022+región",
		SID2	="estrato: región+ámbito"
	)
y=
	N44%>%group_by(VV007)%>%summarize(NN=sum(W1RP))%>%
	mutate(NX=NN*2.5/5)%>%
	left_join(y=d%>%group_by(VV007)%>%summarize(NW=sum(W1RP)),by="VV007")
d=
	d%>%
	left_join(y=y,by="VV007")%>%
	mutate(W1RP=W1RP*NX/NW)%>%
	select(-NN,-NW)
# archivo
save(d,file="X2024031817.rda")
print(date())
}			# load
# ------------------------------------------------------------------------------------------------------------------------ #
# III Artículo
load(file="X2024031817.rda")
# Generación de Estimaciones
if(TRUE){	# estp
s=survey::svydesign(ids=~HV001+CASEID,weights=~W1RP,strata=~SID2,data=subset(d,!is.na(W1RP)&W1RP>0),nest=TRUE)
# exploración nacional
print(date())
m=survey::svyby(formula=~IANE3,by=~HV007,design=s,FUN=survey::svymean,na.rm=TRUE)
z=survey::svyby(formula=~IANE4,by=~HV007,design=s,FUN=survey::svymean,na.rm=TRUE)
R0=
	as_tibble(m)%>%
	rename(se3=se)%>%
	left_join(y=as_tibble(z)%>%rename(se4=se),by="HV007")%>%
	mutate(
		l3=IANE3-ZCRIT*se3,
		u3=IANE3+ZCRIT*se3,
		l4=IANE4-ZCRIT*se4,
		u4=IANE4+ZCRIT*se4
	)
y=d%>%group_by(HV007)%>%summarize(f=n())
R0=R0%>%left_join(y=y,by="HV007")
# exploración en grupos de edad
R1=
	srvyr::as_survey_design(s)%>%
	group_by(FEDA6)%>%
	summarize(
		PR1=srvyr::survey_mean(x=IANE, na.rm=TRUE,vartype=c("ci")),
		PR2=srvyr::survey_mean(x=IANE2,na.rm=TRUE,vartype=c("ci")),
		PR3=srvyr::survey_mean(x=IANE3,na.rm=TRUE,vartype=c("ci")),
		PR4=srvyr::survey_mean(x=IANE4,na.rm=TRUE,vartype=c("ci")),
		PR5=srvyr::survey_mean(x=IANE5,na.rm=TRUE,vartype=c("ci")),
		NNOP=srvyr::unweighted(n())
	)
# exploración en seis dominios
R2=
	srvyr::as_survey_design(s)%>%
	group_by(FAGR6)%>%
	summarize(
		PR1=srvyr::survey_mean(x=IANE, na.rm=TRUE,vartype=c("ci")),
		PR2=srvyr::survey_mean(x=IANE2,na.rm=TRUE,vartype=c("ci")),
		PR3=srvyr::survey_mean(x=IANE3,na.rm=TRUE,vartype=c("ci")),
		PR4=srvyr::survey_mean(x=IANE4,na.rm=TRUE,vartype=c("ci")),
		PR5=srvyr::survey_mean(x=IANE5,na.rm=TRUE,vartype=c("ci")),
		NNOP=srvyr::unweighted(n())
	)
# exploración en seis dominios y años
R3=
	srvyr::as_survey_design(s)%>%
	group_by(FAGR6,HV007)%>%
	summarize(
		PR1=srvyr::survey_mean(x=IANE, na.rm=TRUE,vartype=c("ci")),
		PR2=srvyr::survey_mean(x=IANE2,na.rm=TRUE,vartype=c("ci")),
		PR3=srvyr::survey_mean(x=IANE3,na.rm=TRUE,vartype=c("ci")),
		PR4=srvyr::survey_mean(x=IANE4,na.rm=TRUE,vartype=c("ci")),
		PR5=srvyr::survey_mean(x=IANE5,na.rm=TRUE,vartype=c("ci")),
		NNOP=srvyr::unweighted(n())
	)
# exploración en regiones y años
R4=
	srvyr::as_survey_design(s)%>%
	group_by(HV023,HV007)%>%
	summarize(
		PR1=srvyr::survey_mean(x=IANE, na.rm=TRUE,vartype=c("ci")),
		PR2=srvyr::survey_mean(x=IANE2,na.rm=TRUE,vartype=c("ci")),
		PR3=srvyr::survey_mean(x=IANE3,na.rm=TRUE,vartype=c("ci")),
		PR4=srvyr::survey_mean(x=IANE4,na.rm=TRUE,vartype=c("ci")),
		PR5=srvyr::survey_mean(x=IANE5,na.rm=TRUE,vartype=c("ci")),
		PR6=srvyr::survey_mean(x=IANE6,na.rm=TRUE,vartype=c("ci")),
		NNOP=srvyr::unweighted(n())
	)
# exploración en grupos de altitud
R5=
	srvyr::as_survey_design(s)%>%
	group_by(FALT9)%>%
	summarize(
		PR1=srvyr::survey_mean(x=IANE, na.rm=TRUE,vartype=c("ci")),
		PR2=srvyr::survey_mean(x=IANE2,na.rm=TRUE,vartype=c("ci")),
		PR3=srvyr::survey_mean(x=IANE3,na.rm=TRUE,vartype=c("ci")),
		PR4=srvyr::survey_mean(x=IANE4,na.rm=TRUE,vartype=c("ci")),
		PR5=srvyr::survey_mean(x=IANE5,na.rm=TRUE,vartype=c("ci")),
		NNOP=srvyr::unweighted(n())
	)
# exploración edad x altura x año (u,r)
R9=
	srvyr::as_survey_design(s)%>%
	group_by(FEDA3,FALT3,HV025,HV007)%>%
	summarize(
		PR3=srvyr::survey_mean(x=IANE3,na.rm=TRUE,vartype=c("ci")),
		PR4=srvyr::survey_mean(x=IANE4,na.rm=TRUE,vartype=c("ci")),
		NNOP=srvyr::unweighted(n())
	)
# diferencias
x=
	survey::svydesign(
		ids=~HV001+CASEID,weights=~W1RP,strata=~SID2,
		data=
			d%>%
			filter(!is.na(W1RP)&W1RP>0)%>%
			mutate(
				DNOR=IANE3-IANE4,
				DCAL=IANE6-IANE4,
				HV023=trimws(as.character(haven::as_factor(HV023)))
			)%>%
			select(HV023,HV007,DNOR,DCAL,HV001,CASEID,W1RP,SID2),
		nest=TRUE
	)
m=
	survey::svyby(
		formula=~DNOR,by=~HV023+HV007,design=x,FUN=survey::svymean
	)
r=
	survey::svyby(
		formula=~DCAL,by=~HV023+HV007,design=x,FUN=survey::svymean
	)
z=
	bind_cols(
		as_tibble(m)%>%rename(SNOR=se),
		as_tibble(confint(m))%>%setNames(c("LNOR","UNOR")),
		as_tibble(r)%>%rename(SCAL=se)%>%select(-HV023,-HV007),
		as_tibble(confint(r))%>%setNames(c("LCAL","UCAL"))
	)
R4=
	R4%>%
	mutate(
		HV023=trimws(as.character(haven::as_factor(HV023)))
	)%>%
	left_join(y=z,by=c("HV023","HV007"))
# archivo
save(d,s,R0,R1,R2,R3,R4,R5,R9,file="X2024030810.rda")
print(date())
}			# estp
# Producción de Gráficos
if(TRUE){	# outc
LGRA=list()
# Figura 1
y=
	bind_rows(
		R0%>%
		select(HV007,IANE3,se3,l3,u3)%>%
		setNames(c("HV007","IANE","SEM","LANE","UANE"))%>%
		mutate(NVER="2001")
	,
		R0%>%
		select(HV007,IANE4,se4,l4,u4)%>%
		setNames(c("HV007","IANE","SEM","LANE","UANE"))%>%
		mutate(NVER="2024")
	)%>%
	mutate(
		NVER=factor(x=NVER,levels=c("2024","2001"))
	)%>%
	filter(HV007%in%c(2009:2023))
g=
	ggplot(data=y)+
	geom_ribbon(mapping=aes(x=HV007,ymin=LANE,ymax=UANE,fill=NVER),alpha=0.25)+
	geom_line(mapping=aes(x=HV007,y=IANE,color=NVER))+
	labs(
		x="año",y="prop. prevalencia anemia",color="norma",fill="norma",
		title="Figura 1 Tendencias de Prevalencia Nacional",
		caption=paste0("INEI/ENDES 6-35m"," n=",nrow(filter(d,HV007!=2024)))
	)+
	theme_minimal()
LGRA$G0101=g
# Figura 2
y=
	bind_rows(
		R9%>%
		select(FEDA3,FALT3,HV025,HV007,PR3,PR3_low,PR3_upp)%>%
		setNames(c("FEDA3","FALT3","HV025","HV007","IANE","LANE","UANE"))%>%
		mutate(NVER="2001")
	,
		R9%>%
		select(FEDA3,FALT3,HV025,HV007,PR4,PR4_low,PR4_upp)%>%
		setNames(c("FEDA3","FALT3","HV025","HV007","IANE","LANE","UANE"))%>%
		mutate(NVER="2024")
	)%>%
	mutate(
		HV025=
			factor(
				x=as.character(haven::as_factor(HV025)),
				levels=c("Urbano","Rural")
			),
		NVER=factor(x=NVER,levels=c("2024","2001"))
	)%>%
	filter(HV007%in%c(2009:2023))
g=
	ggplot(data=y)+
	facet_grid(rows=FALT3~FEDA3)+
	geom_ribbon(mapping=aes(x=HV007-2000,ymin=LANE,ymax=UANE,fill=NVER),color=NA,alpha=0.2,data=y%>%filter(HV025=="Urbano"))+
	geom_ribbon(mapping=aes(x=HV007-2000,ymin=LANE,ymax=UANE,fill=NVER),color=NA,alpha=0.1,data=y%>%filter(HV025=="Rural"))+
	geom_line(mapping=aes(x=HV007-2000,y=IANE,color=NVER,linetype=HV025))+
	labs(
		x="año, en el siglo XXI",y="prop. prevalencia anemia",
		color="norma",fill="norma",linetype="ámbito",
		title="Figura 2 Tendencias de Prevalencias Subnacionales",
		caption=paste0("INEI/ENDES 6-35m"," n=",nrow(filter(d,HV007!=2024)))
	)+
	theme_minimal()
LGRA$G0102=g
# Figura 3
y=
	R4%>%
	arrange(HV023,HV007)%>%
	filter(HV007%in%c(2009:2023)&NNOP>=30)%>%
	mutate(
		PR4_low=ifelse(PR4_low<0,0,PR4_low),
		PR4_upp=ifelse(PR4_upp>1,1,PR4_upp),
	)
g=
	ggplot(data=y)+
	geom_hline(yintercept=0,color="pink",linewidth=1)+
	geom_hline(yintercept=c(0.1,-0.1),color="pink",linewidth=1,linetype="dashed")+
	geom_errorbar(mapping=aes(x=PR4,ymin=LNOR,ymax=UNOR),color="lightgray")+
	geom_errorbarh(mapping=aes(y=DNOR,xmin=PR4_low,xmax=PR4_upp),color="lightgray")+
	geom_point(mapping=aes(x=PR4,y=DNOR,color=2050-HV007),alpha=0.5)+
	scale_color_continuous(guide="none")+
	labs(
		x="prevalencia OMS 2024",
		y="diferencias en prevalencia OMS 2001 - 2024",
		title="Figura 3 Prevalencias por Región-Año según Normas",
		caption=
			paste0(
				"INEI/ENDES 6-35m 2009-2023",
				" n=",sum(y$NNOP)," p=",nrow(y),"/",nrow(R4)
			)
	)+
	theme_minimal()
LGRA$G0103=g
# Figura 4
g=
	ggplot(data=y)+
	geom_hline(yintercept=0,color="pink",linewidth=1)+
	geom_hline(yintercept=c(0.05,-0.05),color="pink",linewidth=1,linetype="dashed")+
	geom_errorbar(mapping=aes(x=PR4,ymin=LCAL,ymax=UCAL),color="lightgray")+
	geom_errorbarh(mapping=aes(y=DCAL,xmin=PR4_low,xmax=PR4_upp),color="lightgray")+
	geom_point(mapping=aes(x=PR4,y=DCAL,color=2050-HV007),alpha=0.5)+
	scale_color_continuous(guide="none")+
	labs(
		x="prevalencia, fórmula (continua)",
		y="diferencias en prevalencia, tabla - fórmula",
		title="Figura 4 Prevalencias por Región-Año según OMS 2024",
		caption=
			paste0(
				"INEI/ENDES 6-35m 2009-2023",
				" n=",sum(y$NNOP)," p=",nrow(y),"/",nrow(R4)
			)
	)+
	theme_minimal()
LGRA$G0104=g
}			# outc
# ------------------------------------------------------------------------------------------------------------------------ #
# License:
#
# The data sources for this analysis come from publications and data by 
# the Instituto Nacional de Estadística e Informática (INEI) from Peru, 
# which can be freely obtained at https://proyectos.inei.gob.pe/microdatos/ 
# and https://www.datosabiertos.gob.pe/ under a ODC Open Database License.
# They can also be freely obtained from https://dhsprogram.com/Data/ . 
# Consolidated and anonymized data, as used for the analysis, 
# are freely available in github/vipermcs.
#
# This R program has been developed by Miguel Campos, 
# on the basis of discussion with the co-authors.
# It is placed freely available, with the sole condition of quoting the source.
# Copyright (c) 2024 Miguel Campos under MIT License
# 
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
# 
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
# ------------------------------------------------------------------------------------------------------------------------ #
