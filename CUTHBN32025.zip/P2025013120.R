# P2025013120.R MCNut24.R 2025-Feb-03 vipermcs@gmail.com et al 2021-Mar-08 
# ------------------------------------------------------------------------------------------------------------------------ #
# Basic Packages
require(tidyverse)
require(survey)
require(survival)
require(future)
require(ggpattern)
windows(width=6,height=6,record=TRUE)
options(digits=5,width=240)
options(survey.lonely.psu="adjust")
options(dplyr.summarise.inform=FALSE,dplyr.show_progress=FALSE)
# ------------------------------------------------------------------------------------------------------------------------ #
# Parameters
PCRIT = 0.05
ZCRIT = qnorm(1-PCRIT/2)
ALPHA = PCRIT
DWORK = "Z:\\"			# carpeta de trabajo
DTABS = "X:\\Tabs\\"	# carpeta con tablas, puede ser DTABS="Z:\\"
setwd(DWORK)
RRSEED=prod(as.numeric(unlist(strsplit("9  92  91","\\s+"))))	# https://www.random.org/cgi-bin/randbyte?nbytes=4&format=d 2024-Mar-29 15:50 52
NCORES=parallel::detectCores() 
# ------------------------------------------------------------------------------------------------------------------------ #
# Documentation
# Software for the paper
# "New WHO guideline on the definition of anemia: 
# implications for 6-35 months old children in Peru 2009-2023"
# Miguel Campos, Luis Cordero, Enrique Velásquez, Nelly Baiocchi, 
# Marianella Miranda, María Inés Sánchez-Griñán, Walter Valdivia.
# This code has three parts:
#   I Consolidado ENDES
#     Provided here only as documentation, it will not necessarily execute.
#     Generates N44, a consolidated data frame of ENDES 2009-2023 children.
#     It is used for several purposes in our group.
#     It depends on downloaded ENDES ZIPs in folders for each year,
#     and a table listing files and years for ENDES (in PETabs.rda).
#  II Preparación de Datos
#     Provided here only as documentation, it will not necessarily execute.
#     Generates d, a data frame (tibble), summarized subset of N44.
#     It is used only for analysis in this paper.
# III Artículo
#     It can be executed together with the d data frame.
#     It requires R and the tidyverse & survey packages.
#     It has two sections:
#     - Generation of Weighed Estimates (it can take a while)
#     - Production of Graphs 
# ------------------------------------------------------------------------------------------------------------------------ #
# I Consolidado ENDES
if(FALSE){	# endes
# load(paste(DTABS,"NuTabs.rda",sep=""))
# load(paste(DTABS,"GCTabs.rda",sep=""))
load(paste(DTABS,"PETabs.rda",sep=""))
# Desempaquetado Provisional
DTABw=tempdir()	# DTABS
dir.create(path=paste0(DTABw,"/","ENDES"))
for(s in unique(TENDESF$SrcYear)){
	dir.create(path=paste0(DTABw,"/ENDES/",s))
}
for(s in c("RECH0","RECH23","REC21","REC41","REC42","REC43","REC44","REC91","REC95")){
	y=TENDESF%>%filter(grepl(paste0(s,"."),toupper(SrcFile)))
	for(i in 1:nrow(y)){
		unzip(
			zipfile=paste0(y$SrcPath[i],"/",y$SrcYear[i],"/",y$ZipFile[i]),
			files=y$Name[i],
			exdir=paste0(DTABw,"/ENDES/",y$SrcYear[i],"/"),
			junkpaths=TRUE
		)
	}
}
for(p in c("S2023")){
	r=paste0(DTABw,"/ENDES/",p,"/")
	l=dir(r)
	for(k in 1:length(l)){
		file.rename(
			from=paste0(r,l[k]),
			to=paste0(r,gsub(paste0("_",substr(p,2,5)),"",l[k]))
		)
	}
}
DTABw=paste0(DTABw,"/")
print(date())
# Procesamiento Individualizado
rENDESy=function(yy){
	s=paste0(DTABw,"ENDES\\S",yy,"\\")
	H00=haven::read_sav(file=paste0(s,"RECH0.SAV"))
	if(yy==2014){H00=H00%>%rename(HV005=hv005)}
	if(yy==2016){H00=H00%>%rename(HV005=hv005,HV022=hv022)}
	if(yy>2017){H00=H00%>%mutate(HV016=as.numeric(NA))}
	if(yy==2018){H00=H00%>%mutate(HV007=yy)}
	H03=haven::read_sav(file=paste0(s,"RECH23.SAV"))
	if(yy==2005){
		H03=
			H03%>%
			rename(HHID=hhid,SHREGION=shregion)%>%
			mutate(SHPROVIN=NA,SHDISTRI=NA)
	}
	H03=H03%>%select(one_of("HHID","SHREGION","SHPROVIN","SHDISTRI"))
	R21=
		haven::read_sav(file=paste0(s,"REC21.SAV"))%>%
		rename(HWIDX=BIDX)%>%
		select(one_of("CASEID","HWIDX","B1","B2","B4","B8","B9","B16"))
	if(!yy%in%c(2000,2005)){	# tienen 41 y 42
		R41=
			haven::read_sav(file=paste0(s,"REC41.SAV"))%>%
			mutate(HHID=substr(CASEID,1,15))%>%
			rename(HWIDX=MIDX)%>%
			select(one_of("CASEID","HWIDX","M39"))
		R42=
			haven::read_sav(file=paste0(s,"REC42.SAV"))%>%
			mutate(HHID=substr(CASEID,1,15))%>%
			select(
				CASEID,
				V404,V409,V409A,V410,V410A,V411,V411A,
				V412,V412A,V412B,V413,V413A,V413B,V413C,V413D,
				V414A,V414B,V414C,V414D,V414E,V414F,V414G,V414H,
				V414I,V414J,V414K,V414L,V414M,V414N,V414O,V414P,
				V414Q,V414R,V414S,V414T,V414U
			)
	}					# tienen 41 y 42
	R43=
		haven::read_sav(file=paste0(s,"REC43.SAV"))%>%
		rename(HWIDX=HIDX)%>%
		select(CASEID,HWIDX,H11)
	R44=haven::read_sav(file=paste0(s,"REC44.SAV"))
	if(yy>=2012){	# longitud de CASEID
		R44=R44%>%mutate(HHID=substr(CASEID,1,15))
	}else{
		R44=R44%>%mutate(HHID=substr(CASEID,1,12))
	}
	KNA=as.numeric(NA)
	if(!yy%in%c(2000)){	# tienen R91
		m=c("CASEID","SREGION","SSEMES","SPROVIN","SDISTRI",
			"S492A","S492B","S492C","S492D","S492E","S492F","S492G",
			"S493A","S493B","S493C","S493D","S493E","S493F","S493G","S493H","S493I","S493J","S493K","S493L","S493M","S493N","S493O","S493P",
			"S494","S494A","S494B"
		)
		R91=
			haven::read_sav(file=paste0(s,"REC91.SAV"))
		if(yy==2009){
			R91=
				R91%>%
				mutate(
					S119=S118A,S119NA=KNA,S119NB=KNA,S119D=KNA,
					S492A=NA,S492B=NA,S492C=NA,S492D=NA,S492E=NA,
					S492F=NA,S492G=NA,
					S493A=NA,S493B=NA,S493C=NA,S493D=NA,S493E=NA,
					S493F=NA,S493G=NA,S493H=NA,S493I=NA,S493J=NA,
					S493K=NA,S493L=NA,S493M=NA,S493N=NA,S493O=NA,S493P=NA,
					S494=NA,S494A=NA,S494B=NA
				)
		}else if(yy%in%c(2005)){
			R91=
				R91%>%
				mutate(
					SSEMES=STRIMES,
					S119=KNA,S119NA=S119C,S119NB=S119A,S119D=KNA,
					S492A=NA,S492B=NA,S492C=NA,S492D=NA,S492E=NA,
					S492F=NA,S492G=NA,
					S493A=NA,S493B=NA,S493C=NA,S493D=NA,S493E=NA,
					S493F=NA,S493G=NA,S493H=NA,S493I=NA,S493J=NA,
					S493K=NA,S493L=NA,S493M=NA,S493N=NA,S493O=NA,S493P=NA,
					S494=NA,S494A=NA,S494B=NA
				)
		}else if(yy%in%c(2007:2008)){
			R91=
				R91%>%
				mutate(
					SSEMES=STRIMES,
					S119=S118A,S119NA=S119C,S119NB=S119A,S119D=KNA,
					S492A=NA,S492B=NA,S492C=NA,S492D=NA,S492E=NA,
					S492F=NA,S492G=NA,
					S493A=NA,S493B=NA,S493C=NA,S493D=NA,S493E=NA,
					S493F=NA,S493G=NA,S493H=NA,S493I=NA,S493J=NA,
					S493K=NA,S493L=NA,S493M=NA,S493N=NA,S493O=NA,S493P=NA,
					S494=NA,S494A=NA,S494B=NA
				)
		}else if(yy%in%c(2010:2013)){
			R91=
				R91%>%
				mutate(
					S119NA=KNA,S119NB=KNA,S119D=KNA
				)
		}else if(yy%in%c(2014)){
			R91=
				R91%>%
				mutate(
					S119NA=KNA,S119NB=KNA,S119D=KNA,
					SREGION=sregion
				)
		}else if(yy%in%c(2015:2016)){
			R91=
				R91%>%
				mutate(
					S119NA=KNA,S119NB=KNA,S119D=KNA
				)
		}
		R91=R91%>%select(S119,S119NA,S119NB,S119D,one_of(m))
	}					# tienen R91
	if(!yy%in%c(2000,2005)){	# tienen R95
		R95=
			haven::read_sav(file=paste0(s,"REC95.SAV"))
		if(yy%in%c(2007,2008,2009:2012)){
			R95=R95%>%mutate(S465EA=NA,S465EB=NA,S465EC=NA,S465ED=NA)
		}
		if(yy%in%c(2009)){
			R95=
				R95%>%
				rename(
					S476AN1=S482BDN1,
					S476AS1=S482BDS1,
					S476AT1=S482BDT1,
					S476AR1=S482BDR1,
					S476AN2=S482BDN2,
					S476AS2=S482BDS2,
					S476AT2=S482BDT2,
					S476AR2=S482BDR2,
					S476AN3=S482BDN3,
					S476AS3=S482BDS3,
					S476AT3=S482BDT3,
					S476AR3=S482BDR3,
					S476AN4=S482BDN4,
					S476AS4=S482BDS4,
					S476AT4=S482BDT4,
					S476AR4=S482BDR4,
					S476AN5=S482BDN5,
					S476AS5=S482BDS5,
					S476AT5=S482BDT5,
					S476AR5=S482BDR5,
					S476AN6=S482BDN6,
					S476AS6=S482BDS6,
					S476AT6=S482BDT6,
					S476AR6=S482BDR6,
					S476AN7=S482BDN7,
					S476AS7=S482BDS7,
					S476AT7=S482BDT7,
					S476AR7=S482BDR7
				)
		}else if(yy%in%c(2007,2008)){
			R95=
				R95%>%
				mutate(
					S476AN1=as.numeric(NA),
					S476AS1=as.numeric(NA),
					S476AT1=as.numeric(NA),
					S476AR1=as.numeric(NA),
					S476AN2=as.numeric(NA),
					S476AS2=as.numeric(NA),
					S476AT2=as.numeric(NA),
					S476AR2=as.numeric(NA),
					S476AN3=as.numeric(NA),
					S476AS3=as.numeric(NA),
					S476AT3=as.numeric(NA),
					S476AR3=as.numeric(NA),
					S476AN4=as.numeric(NA),
					S476AS4=as.numeric(NA),
					S476AT4=as.numeric(NA),
					S476AR4=as.numeric(NA),
					S476AN5=as.numeric(NA),
					S476AS5=as.numeric(NA),
					S476AT5=as.numeric(NA),
					S476AR5=as.numeric(NA),
					S476AN6=as.numeric(NA),
					S476AS6=as.numeric(NA),
					S476AT6=as.numeric(NA),
					S476AR6=as.numeric(NA),
					S476AN7=as.numeric(NA),
					S476AS7=as.numeric(NA),
					S476AT7=as.numeric(NA),
					S476AR7=as.numeric(NA)
				)
		}
		R95=R95%>%rename(HWIDX=IDX95)
		if(yy%in%c(2009:2012)){
			R95=
				R95%>%
				select(
					CASEID,HWIDX,
					S465EA,S465EB,S465EC,S465ED,S466:S466C,
					S476AN1:S476AR7,S45RT1:S45RT2Y
				)
		}else if(yy%in%c(2007,2008)){
			R95=
				R95%>%
				select(
					CASEID,HWIDX,
					S465EA,S465EB,S465EC,S465ED,S466:S466C,
					S476AN1:S476AR7
				)
		}
	}					# tienen R95
	h00=
		H00%>%
		mutate(
			HHID=as.character(HHID),
			W1R=HV005/1E6,
			SID=HV022*100+HV023
		)%>%
		mutate(
			VV007=yy,
			VV006=HV008-12*(HV007-1900)
		)%>%
		select(one_of(c(
			"HHID","W1R","SID",
			"HV001","HV022","HV023","HV025","HV026",
			"HV007","VV006","VV007","HV016","HV040"
		)))%>%	# ,"HV024","HV015","HV042"
		left_join(y=H03,by=(c("HHID")))
	rXX=R44
	if(!yy%in%c(2000,2005)){
		r42=
			R42%>%
			left_join(
				y=
					R21%>%
					filter(B9==0)%>%
					group_by(CASEID)%>%
					summarize(B8=min(B8,na.rm=TRUE))%>%
					left_join(
						y=
							R21%>%
							filter(B9==0)%>%
							select(CASEID,B8,B16,HWIDX),
						by=c("CASEID","B8"))%>%
					group_by(CASEID)%>%
					summarize(HWIDX=head(HWIDX,1)),
				by=c("CASEID")
			)
		rXX=
			rXX%>%
			left_join(h00,by=c("HHID"))%>%
			left_join(R95,by=c("CASEID","HWIDX"))%>%
			left_join(R21,by=c("CASEID","HWIDX"))%>%
			left_join(R41,by=c("CASEID","HWIDX"))%>%
			left_join(r42,by=c("CASEID","HWIDX"))%>%
			left_join(R43,by=c("CASEID","HWIDX"))%>%
			left_join(R91,by=c("CASEID"))
		if(yy%in%c(2004:2008)){rXX=rXX%>%filter(HV007==VV007)}
		L=
			list(
				H00=H00,H03=H03,
				R21=R21,
				R41=R41,R42=R42,R43=R43,R44=R44,
				R91=R91,R95=R95,
				h00=h00,r42=r42,rXX=rXX
			)
	}
	if(yy%in%c(2000,2005)){
		rXX=
			rXX%>%
			left_join(h00,by=c("HHID"))%>%
			mutate(S465EA=NA,S465EB=NA,S465EC=NA,S465ED=NA)%>%
			left_join(R21,by=c("CASEID","HWIDX"))%>%
			left_join(R43,by=c("CASEID","HWIDX"))
		if(yy%in%c(2004:2008)){rXX=rXX%>%filter(HV007==VV007)}
		L=
			list(
				H00=H00,H03=H03,
				R21=R21,
				R43=R43,R44=R44,
				h00=h00,rXX=rXX
			)
	}
	return(L)
}
# Ciclo 2021-2023
r=rENDESy(yy=2023);r4423=r$rXX
r=rENDESy(yy=2022);r4422=r$rXX
r=rENDESy(yy=2021);r4421=r$rXX
# Ciclo 2018-2020
r=rENDESy(yy=2020);r4420=r$rXX
r=rENDESy(yy=2019);r4419=r$rXX
r=rENDESy(yy=2018);r4418=r$rXX
# Ciclo 2015-2017
r=rENDESy(yy=2017);r4417=r$rXX
r=rENDESy(yy=2016);r4416=r$rXX
r=rENDESy(yy=2015);r4415=r$rXX
# Ciclo 2012-2014
r=rENDESy(yy=2014);r4414=r$rXX
r=rENDESy(yy=2013);r4413=r$rXX
r=rENDESy(yy=2012);r4412=r$rXX
# Ciclo 2009-2011
r=rENDESy(yy=2011);r4411=r$rXX
r=rENDESy(yy=2010);r4410=r$rXX
r=rENDESy(yy=2009);r4409=r$rXX
# Ciclo 2004-2008
r=rENDESy(yy=2008);r4408=r$rXX
r=rENDESy(yy=2007);r4407=r$rXX
r=rENDESy(yy=2005);r4405=r$rXX
# Años Anteriores
r=rENDESy(yy=2000);r4400=r$rXX
# Consolidación
FFULL=TRUE
if(!FFULL){
	load(file="ENDESV20.rda")
	N44=bind_rows(r4423,N44)
}else{
	N44=
		bind_rows(
			r4423,r4422,r4421,
			r4420,r4419,r4418,
			r4417,r4416,r4415,
			r4414,r4413,r4412,
			r4411,r4410,r4409,
			r4408,r4407,r4405,r4400
		)
}
N44=
	N44%>%
	mutate(
		FEnt=as.Date(paste(VV006,"/",HV016,"/",HV007,sep=""),"%m/%d/%Y"),	# está en FENT
		FNac=as.Date(paste(B1,"/15/",B2,sep=""),"%m/%d/%Y")
	)%>%
	mutate(
		EdadM=ifelse(HV007%in%c(2018),HW1,as.numeric(FEnt-FNac)/30.4375),
		IDTE=ifelse(is.na(HW70),NA,ifelse(HW70>6000,NA,ifelse(HW70<(-200),1,0))),
		IDPT=ifelse(is.na(HW72),NA,ifelse(HW72>6000,NA,ifelse(HW72<(-200),1,0))),
		ISPO=ifelse(is.na(HW70),NA,ifelse(HW70>6000,NA,ifelse(HW70>200,1,0))),
		ISF7=ifelse(is.na(S465EA)&is.na(S465EB)&is.na(S465EC)&is.na(S465ED),NA,ifelse(S465EA==1|S465EB==1|S465EC==1|S465ED==1,1,0)),
		HW56=ifelse(HW56<20|HW56>400,NA,HW56),
		IANE=ifelse(is.na(HW56),NA,ifelse(HW56<110,1,0)),
		GA12=12*as.integer(HW1/12)+6
	)%>%
	mutate(
		GEDA=as.integer(HW1/ifelse(HW1<6,3,ifelse(HW1<12,6,12)))*ifelse(HW1<6,3,ifelse(HW1<12,6,12))+ifelse(HW1<6,3,ifelse(HW1<12,6,12))/2,
		FENT=ISOdate(HV007,VV006,HV016)
	)
# Ponderación Conjunta
x=
	TPPBE17%>%
	filter(EDADS%in%0:2)%>%
	select(EDADS,A2000,A2003:A2007,A2008,A2009:A2023)
y=(x[1,-1]/2+x[2,-1]+x[3,-1])
z=N44%>%group_by(VV007)%>%summarize(TW1R=sum(W1R,na.rm=TRUE))
u=unlist(sapply(1:nrow(N44),function(i){(N44$W1R[i]/z$TW1R[z$VV007==N44$VV007[i]])*y[1,paste0("A",as.character(N44$VV007[i]))]}))
N44$W1RP=u
Q44=survey::svydesign(ids=~HV001+CASEID,weights=~W1RP,strata=~SID,data=subset(N44,!is.na(W1RP)&W1RP>0),nest=TRUE)
save(N44,Q44,file="ENDESV20.rda")
print(date())
}			# endes
# ------------------------------------------------------------------------------------------------------------------------ #
# II Preparación de Datos
if(FALSE){	# load
load(file="X:/Work/ENDESV20.rda")	# consolidado (ENDEStxx.R, PETabs.R)
print(date())
# re-cálculo en ENDES, adaptado de MSG1808.R (para CHANE)
Y=
	N44%>%
	mutate(
		FEnt=as.Date(paste(VV006,"/",HW17,"/",HV007,sep=""),"%m/%d/%Y"),	# está en FENT
		FNac=as.Date(paste(B1,"/",as.character(haven::as_factor(HW16)),"/",B2,sep=""),"%m/%d/%Y")
	)%>%
	mutate(
		EDM=if_else(FEnt>FNac,as.numeric(FEnt-FNac)/30.4375,NA),
	)
d=
	Y%>%
	filter(HV007>2008&!is.na(IANE)&!is.na(HW1)&HW1>=6&HW1<36)%>%
	mutate(
		HVGR6=ifelse(SHREGION==1,1,ifelse(HV040>=3000,4,HV025+ifelse(SHREGION==4,4,1))),
		HV0YM=HV007+0.5/12+(VV006-1)/12,
		FPM=ifelse(HV007<2014,1,ifelse(HV007<2015,2,3)),
		AAS=(0.0048108*HV040)+(0.0000004*HV040^2),			# Sharma 2019
		AAW=((-0.032*(HV040*0.0032808)+0.022*(HV040*0.0032808)^2)*10),	# CDC 1989, WHO 2011
		A24=(0.0056384*HV040)+(0.0000003*HV040^2),			# WHO 2024, continuous
		AS4=c(0,4,8,11,14,18,21,25,29,33)[(ifelse(HV040>=5000,4999,HV040)%/%500)+1],			# WHO 2024, staircase
		SID2=HV023*10+HV025
	)%>%
	mutate(
		IANE2=ifelse(is.na(HW56),NA,ifelse(HW56<100,1,0)),
		IANE3=ifelse(is.na(HW56),NA,ifelse((HW53-ifelse(HV040<1000,0,AAW))<110,1,0)),
		IANE5=ifelse(is.na(HW56),NA,ifelse((HW53-AAS)<10*(9.8+HW1/30),1,0)),
		IANE4=ifelse(is.na(HW56),NA,ifelse((HW53-A24)<ifelse(HW1<24,105,110),1,0)),
		IANE6=ifelse(is.na(HW56),NA,ifelse((HW53-AS4)<ifelse(HW1<24,105,110),1,0)),
		HVLYM=log(HV0YM),
		FAGR6=factor(x=HVGR6,labels=c("Lima","C y S Urb <3Km","C y S Rur <3Km","Sierra 3+ Km","Selva Urb","Selva Rur")),
		FEDA6=factor(x=6*as.integer(HW1/6),labels=c("6-11m","12-17m","18-23m","24-29m","30-35m")),
		FALT9=factor(x=0.5*as.integer(ifelse(HV040>4500,4500,HV040)/500)),
		FEDA3=factor(x=12*as.integer(HW1/12),labels=c("6-11m","12-23m","24-35m")),
		FALT3=factor(x=ifelse(HV040<1000,0,ifelse(HV040<3000,2000,3500)),labels=c("0-0.9km","1-2.9km","3+km")),
		IANE3A=ifelse(is.na(HW56),NA,ifelse((HW53-AAW)<110,1,0)),
		IANE3B=ifelse(is.na(HW56),NA,ifelse((HW53-ifelse(HV040<1000,0,AAW))<110,1,0)),
		BURB2=ifelse(as.character(haven::as_factor(HV025))=="Urbano",0,1),
		BEDA2=ifelse(HW1<24,0,1),
		FY1=ifelse(FPM==1,0,1),
		FY2=ifelse(FPM==3,1,0)
	)%>%
	mutate(
		DNOR=IANE3-IANE4,
		DCAL=IANE6-IANE4
	)%>%
	mutate(
		DNAS=if_else(DNOR==(-1),1,0),
		DSAN=if_else(DNOR==1,1,0),
		DCAM=if_else(DNOR==0,0,1)
	)%>%
	mutate(across(c(HV023,HV025),~haven::as_factor(.)))%>%
	select(
		HV007,VV007,VV006,HV0YM,HVLYM,EDM,HW1,B4,IANE,HW56,HW53,
		AAW,AAS,A24,AS4,IANE2,IANE3,IANE5,IANE4,IANE6,
		DNOR,DCAL,DNAS,DSAN,DCAM,
		HVGR6,FAGR6,FEDA6,FALT9,FEDA3,FALT3,
		IANE3A,IANE3B,BURB2,BEDA2,FPM,FY1,FY2,
		HV001,HV023,HV025,HV026,HV040,SHREGION,CASEID,W1RP,SID,SID2
	)%>%
	filter(HV007==VV007)%>%
	labelled::set_variable_labels(
		HV007	="año de encuesta (real)",
		VV007	="año de encuesta (nominal)",
		VV006	="mes de encuesta",
		HV0YM	="mes y fracción de encuesta",
		HVLYM	="log natural del mes y fracción",
		EDM 	="edad, meses y decimales, recalc",
		HW1 	="edad, meses cumplidos",
		B4  	="sexo",
		IANE	="anemia (DHS)",
		HW56	="hb corregida (DHS)",
		HW53	="hb sin corregir",
		AAW 	="ajuste WHO 2011",
		AAS 	="ajuste Sharma 2019",
		A24 	="ajuste WHO 2024, continuo",
		AS4 	="ajuste WHO 2024, escalera",
		IANE2	="anemia (10)",
		IANE3	="anemia (WHO 2001)",
		IANE5	="anemia (Sharma, edad ad hoc)",
		IANE4	="anemia (WHO 2024, continua)",
		DNOR	="diferencia estado de anemia 2001-2024",
		DCAL	="diferencia estado de anemia tabla-fórmula",
		DNAS	="cambió de no anémico 2001 a anémico 2024",
		DSAN	="cambió de anémico 2001 a no anémico 2024",
		DCAM	="cambió diagnóstico 2001 vs 2024",
		IANE6	="anemia (WHO 2024, escalera)",
		HVGR6	="zona ecológica (6)",
		FAGR6	="zona ecoaltura (6)",
		FEDA6	="edad (semestres)",
		FALT9	="altitud (500m 9)",
		FEDA3	="edad (años)",
		FALT3	="altitud (3)",
		FPM 	="ciclo ENDES",
		FY1 	="ciclo ENDES 1",
		FY2 	="ciclo ENDES 2",
		HV040	="altitud m snm",
		CASEID	="id sujeto",
		W1RP	="ponderación, reescalada",
		SID 	="estrato: HV022+región",
		SID2	="estrato: región+ámbito"
	)
# reponderación, homogeneización
y=
	N44%>%group_by(VV007)%>%summarize(NN=sum(W1RP))%>%
	mutate(NX=NN*2.5/5)%>%
	left_join(y=d%>%group_by(VV007)%>%summarize(NW=sum(W1RP)),by="VV007")
d=
	d%>%
	left_join(y=y,by="VV007")%>%
	mutate(W1RP=W1RP*NX/NW)%>%
	select(-NN,-NW)
# diseño de la muestra
s=survey::svydesign(ids=~HV001+CASEID,weights=~W1RP,strata=~SID2,data=d,nest=TRUE)
# parche descriptivo
y=
	Y%>%
	mutate(HV023=haven::as_factor(HV023))%>%
	group_by(HV023)%>%
	summarize(
		NN44=n(),
		NYA9=sum(if_else(VV007>2008&(is.na(EDM)|(EDM>=6&EDM<36)),1,0)),
	)%>%
	left_join(y=d%>%group_by(HV023)%>%summarize(NDIN=n()),by="HV023")
z=
	Y%>%
	group_by(VV007)%>%
	summarize(
		NN44=n(),
		NYA9=sum(if_else(VV007>2008&(is.na(EDM)|(EDM>=6&EDM<36)),1,0)),
		DE=min(FEnt,na.rm=TRUE),HA=max(FEnt,na.rm=TRUE)
	)%>%
	left_join(y=d%>%group_by(VV007)%>%summarize(NDIN=n()),by="VV007")
print(date())
# archivo
save(d,file="X2024031817.rda")
print(date())
}			# load
# ------------------------------------------------------------------------------------------------------------------------ #
# III Artículo
load(file="X2024031817.rda")
# Generación de Estimaciones
if(TRUE){	# estp
LEST=list()
# ------------------------------------------------------------------------------------------------------------------------ #
# RY0 resumen antes de la exclusión
if(TRUE){
LEST$RY0=y
z=
	z%>%
	mutate(
		CIC=
			case_when(
				VV007==2000~"00",
				VV007>=2004&VV007<=2008~"04-08",
				VV007>=2009&VV007<=2023~paste0(
					sprintf("%02d",(3*(VV007-2009)%/%3)+9),
					"-",
					sprintf("%02d",(3*(VV007-2009)%/%3)+9+2)
					),
				TRUE~NA
			),
		MMU=
			case_when(
				VV007>=2009&VV007<=2014~"CNPV 2007",
				VV007>=2015&VV007<=2020~"CNPV+SISFOH",
				VV007>=2021&VV007<=2023~"CNPV 2017",
				TRUE~NA
			),
		DMU=
			case_when(
				VV007>=2009&VV007<=2014~"Estratificado Bietápico",
				VV007>=2015&VV007<=2023~"Equilibrado",
				TRUE~NA
			),
		DNO=
			case_when(
				VV007>=2012&VV007<=2014~"+Hogares Secundarios",
				VV007==2020~"Pandemia, Parte Virtual",
				TRUE~NA
			)
	)
LEST$RZ0=z
}
# ------------------------------------------------------------------------------------------------------------------------ #
# R0 estimaciones nacionales
if(TRUE){
print(date())
m=survey::svyby(formula=~IANE3,by=~HV007,design=s,FUN=survey::svymean,na.rm=TRUE)
z=survey::svyby(formula=~IANE4,by=~HV007,design=s,FUN=survey::svymean,na.rm=TRUE)
v=survey::svyby(formula=~DNOR, by=~HV007,design=s,FUN=survey::svymean,na.rm=TRUE)
r=
	as_tibble(m)%>%
	rename(se3=se)%>%
	left_join(y=as_tibble(z)%>%rename(se4=se),by="HV007")%>%
	left_join(y=as_tibble(v)%>%rename(sed=se),by="HV007")%>%
	mutate(
		l3=IANE3-ZCRIT*se3,
		u3=IANE3+ZCRIT*se3,
		l4=IANE4-ZCRIT*se4,
		u4=IANE4+ZCRIT*se4,
		ld=DNOR-ZCRIT*sed,
		ud=DNOR+ZCRIT*sed
	)
y=d%>%group_by(HV007)%>%summarize(f=n())
r=r%>%left_join(y=y,by="HV007")
LEST$R0 =r 	# estimaciones nacionales
}
# ------------------------------------------------------------------------------------------------------------------------ #
# R1 estimaciones en grupos de edad
if(TRUE){
r=
	srvyr::as_survey_design(s)%>%
	group_by(FEDA6)%>%
	summarize(
		PR1=srvyr::survey_mean(x=IANE, na.rm=TRUE,vartype=c("ci")),
		PR2=srvyr::survey_mean(x=IANE2,na.rm=TRUE,vartype=c("ci")),
		PR3=srvyr::survey_mean(x=IANE3,na.rm=TRUE,vartype=c("ci")),
		PR4=srvyr::survey_mean(x=IANE4,na.rm=TRUE,vartype=c("ci")),
		PR5=srvyr::survey_mean(x=IANE5,na.rm=TRUE,vartype=c("ci")),
		NNOP=srvyr::unweighted(n())
	)
LEST$R1 =r 	# estimaciones por grupos de edad
}
# ------------------------------------------------------------------------------------------------------------------------ #
# R2 estimaciones en seis dominios
if(TRUE){
r=
	srvyr::as_survey_design(s)%>%
	group_by(FAGR6)%>%
	summarize(
		PR1=srvyr::survey_mean(x=IANE, na.rm=TRUE,vartype=c("ci")),
		PR2=srvyr::survey_mean(x=IANE2,na.rm=TRUE,vartype=c("ci")),
		PR3=srvyr::survey_mean(x=IANE3,na.rm=TRUE,vartype=c("ci")),
		PR4=srvyr::survey_mean(x=IANE4,na.rm=TRUE,vartype=c("ci")),
		PR5=srvyr::survey_mean(x=IANE5,na.rm=TRUE,vartype=c("ci")),
		NNOP=srvyr::unweighted(n())
	)
LEST$R2 =r 	# estimaciones por dominio
}
# ------------------------------------------------------------------------------------------------------------------------ #
# R3 estimaciones en seis dominios y años
if(TRUE){
r=
	srvyr::as_survey_design(s)%>%
	group_by(FAGR6,HV007)%>%
	summarize(
		PR1=srvyr::survey_mean(x=IANE, na.rm=TRUE,vartype=c("ci")),
		PR2=srvyr::survey_mean(x=IANE2,na.rm=TRUE,vartype=c("ci")),
		PR3=srvyr::survey_mean(x=IANE3,na.rm=TRUE,vartype=c("ci")),
		PR4=srvyr::survey_mean(x=IANE4,na.rm=TRUE,vartype=c("ci")),
		PR5=srvyr::survey_mean(x=IANE5,na.rm=TRUE,vartype=c("ci")),
		NNOP=srvyr::unweighted(n())
	)
LEST$R3 =r 	# estimaciones por dominio-año
}
# ------------------------------------------------------------------------------------------------------------------------ #
# R4 estimaciones en regiones y años
if(TRUE){
r=
	srvyr::as_survey_design(s)%>%
	group_by(HV023,HV007)%>%
	summarize(
		PR1=srvyr::survey_mean(x=IANE, na.rm=TRUE,vartype=c("ci")),
		PR2=srvyr::survey_mean(x=IANE2,na.rm=TRUE,vartype=c("ci")),
		PR3=srvyr::survey_mean(x=IANE3,na.rm=TRUE,vartype=c("ci")),
		PR4=srvyr::survey_mean(x=IANE4,na.rm=TRUE,vartype=c("ci")),
		PR5=srvyr::survey_mean(x=IANE5,na.rm=TRUE,vartype=c("ci")),
		PR6=srvyr::survey_mean(x=IANE6,na.rm=TRUE,vartype=c("ci")),
		DNOR=srvyr::survey_mean(x=DNOR,na.rm=TRUE,vartype=c("ci")),
		DCAL=srvyr::survey_mean(x=DCAL,na.rm=TRUE,vartype=c("ci")),
		PNAS=srvyr::survey_mean(x=DNAS,na.rm=TRUE,vartype=c("ci")),
		PSAN=srvyr::survey_mean(x=DSAN,na.rm=TRUE,vartype=c("ci")),
		PCAM=srvyr::survey_mean(x=DCAM,na.rm=TRUE,vartype=c("ci")),
		SWTO=sum(W1RP),
		NNOP=srvyr::unweighted(n())
	)
LEST$R4 =r 	# estimaciones por región-año
}
# ------------------------------------------------------------------------------------------------------------------------ #
# R4A estimaciones en regiones y ámbitos
if(TRUE){
r=
	srvyr::as_survey_design(s)%>%
	group_by(HV023,HV025)%>%
	summarize(
		PR1=srvyr::survey_mean(x=IANE, na.rm=TRUE,vartype=c("ci")),
		PR2=srvyr::survey_mean(x=IANE2,na.rm=TRUE,vartype=c("ci")),
		PR3=srvyr::survey_mean(x=IANE3,na.rm=TRUE,vartype=c("ci")),
		PR4=srvyr::survey_mean(x=IANE4,na.rm=TRUE,vartype=c("ci")),
		PR5=srvyr::survey_mean(x=IANE5,na.rm=TRUE,vartype=c("ci")),
		PR6=srvyr::survey_mean(x=IANE6,na.rm=TRUE,vartype=c("ci")),
		DNOR=srvyr::survey_mean(x=DNOR,na.rm=TRUE,vartype=c("ci")),
		DCAL=srvyr::survey_mean(x=DCAL,na.rm=TRUE,vartype=c("ci")),
		PNAS=srvyr::survey_mean(x=DNAS,na.rm=TRUE,vartype=c("ci")),
		PSAN=srvyr::survey_mean(x=DSAN,na.rm=TRUE,vartype=c("ci")),
		PCAM=srvyr::survey_mean(x=DCAM,na.rm=TRUE,vartype=c("ci")),
		SWTO=sum(W1RP),
		NNOP=srvyr::unweighted(n())
	)
LEST$R4A=r	# estimaciones por región-ámbito
}
# ------------------------------------------------------------------------------------------------------------------------ #
# R4B estimaciones en regiones
if(TRUE){
r=
	srvyr::as_survey_design(s)%>%
	group_by(HV023)%>%
	summarize(
		PR1=srvyr::survey_mean(x=IANE, na.rm=TRUE,vartype=c("ci")),
		PR2=srvyr::survey_mean(x=IANE2,na.rm=TRUE,vartype=c("ci")),
		PR3=srvyr::survey_mean(x=IANE3,na.rm=TRUE,vartype=c("ci")),
		PR4=srvyr::survey_mean(x=IANE4,na.rm=TRUE,vartype=c("ci")),
		PR5=srvyr::survey_mean(x=IANE5,na.rm=TRUE,vartype=c("ci")),
		PR6=srvyr::survey_mean(x=IANE6,na.rm=TRUE,vartype=c("ci")),
		DNOR=srvyr::survey_mean(x=DNOR,na.rm=TRUE,vartype=c("ci")),
		DCAL=srvyr::survey_mean(x=DCAL,na.rm=TRUE,vartype=c("ci")),
		PNAS=srvyr::survey_mean(x=DNAS,na.rm=TRUE,vartype=c("ci")),
		PSAN=srvyr::survey_mean(x=DSAN,na.rm=TRUE,vartype=c("ci")),
		PCAM=srvyr::survey_mean(x=DCAM,na.rm=TRUE,vartype=c("ci")),
		SWTO=sum(W1RP),
		NNOP=srvyr::unweighted(n())
	)
LEST$R4B=r	# estimaciones por región
}
# ------------------------------------------------------------------------------------------------------------------------ #
# R4C estimaciones en regiones, ámbitos y años
if(TRUE){
r=
	srvyr::as_survey_design(s)%>%
	group_by(HV023,HV025,HV007)%>%
	summarize(
		PR3=srvyr::survey_mean(x=IANE3,na.rm=TRUE,vartype=c("ci")),
		PR4=srvyr::survey_mean(x=IANE4,na.rm=TRUE,vartype=c("ci")),
		PR6=srvyr::survey_mean(x=IANE6,na.rm=TRUE,vartype=c("ci")),
		DNOR=srvyr::survey_mean(x=DNOR,na.rm=TRUE,vartype=c("ci")),
		DCAL=srvyr::survey_mean(x=DCAL,na.rm=TRUE,vartype=c("ci")),
		PNAS=srvyr::survey_mean(x=DNAS,na.rm=TRUE,vartype=c("ci")),
		PSAN=srvyr::survey_mean(x=DSAN,na.rm=TRUE,vartype=c("ci")),
		PCAM=srvyr::survey_mean(x=DCAM,na.rm=TRUE,vartype=c("ci")),
		SWTO=sum(W1RP),
		NNOP=srvyr::unweighted(n())
	)
LEST$R4C=r	# estimaciones por región-ámbito-año
}
# ------------------------------------------------------------------------------------------------------------------------ #
# R4D identificación de extremos
if(TRUE){
a=LEST$R4C
b=LEST$R4B
u=
	bind_rows(
		a%>%
		filter(DNOR!=0)%>%
		mutate(XE=DNOR,XL=DNOR_low,XU=DNOR_upp)%>%
		filter(abs(XE)%in%range(abs(a$DNOR[a$DNOR!=0])))%>%
		arrange(abs(XE))%>%
		select(HV023,HV025,HV007,XE,XL,XU,NNOP)%>%
		mutate(IND="DNOR",GRP="RAY")
	,
		a%>%
		filter(PCAM!=0)%>%
		mutate(XE=PCAM,XL=PCAM_low,XU=PCAM_upp)%>%
		filter(XE%in%range(a$PCAM[a$PCAM!=0]))%>%
		arrange(XE)%>%
		select(HV023,HV025,HV007,XE,XL,XU,NNOP)%>%
		mutate(IND="PCAM",GRP="RAY")
	)
v=
	bind_rows(
		b%>%
		mutate(XE=DNOR,XL=DNOR_low,XU=DNOR_upp)%>%
		filter(abs(XE)%in%range(abs(b$DNOR)))%>%
		arrange(abs(XE))%>%
		select(HV023,XE,XL,XU,NNOP)%>%
		mutate(IND="DNOR",GRP="R")
	,
		b%>%
		mutate(XE=PCAM,XL=PCAM_low,XU=PCAM_upp)%>%
		filter(XE%in%range(b$PCAM))%>%
		arrange(XE)%>%
		select(HV023,XE,XL,XU,NNOP)%>%
		mutate(IND="PCAM",GRP="R")
	)%>%
	mutate(HV025="Ambos",HV007=0)
r=bind_rows(u,v)%>%mutate(HV023=trimws(as.character(HV023)))
LEST$R4D=r	# resumenes de casos extremos
}
# ------------------------------------------------------------------------------------------------------------------------ #
# R5 estimaciones en grupos de altitud
if(TRUE){
r=
	srvyr::as_survey_design(s)%>%
	group_by(FALT9)%>%
	summarize(
		PR1=srvyr::survey_mean(x=IANE, na.rm=TRUE,vartype=c("ci")),
		PR2=srvyr::survey_mean(x=IANE2,na.rm=TRUE,vartype=c("ci")),
		PR3=srvyr::survey_mean(x=IANE3,na.rm=TRUE,vartype=c("ci")),
		PR4=srvyr::survey_mean(x=IANE4,na.rm=TRUE,vartype=c("ci")),
		PR5=srvyr::survey_mean(x=IANE5,na.rm=TRUE,vartype=c("ci")),
		NNOP=srvyr::unweighted(n())
	)
LEST$R5 =r 	# estimaciones por grupos de altitud
}
# ------------------------------------------------------------------------------------------------------------------------ #
# R9 estimaciones edad x altura x año (u,r)
if(TRUE){
r=
	srvyr::as_survey_design(s)%>%
	group_by(FEDA3,FALT3,HV025,HV007)%>%
	summarize(
		PR3=srvyr::survey_mean(x=IANE3,na.rm=TRUE,vartype=c("ci")),
		PR4=srvyr::survey_mean(x=IANE4,na.rm=TRUE,vartype=c("ci")),
		NNOP=srvyr::unweighted(n())
	)
LEST$R9 =r 	# estimaciones por grupos de altitud-edad-ámbito-año
}
# ------------------------------------------------------------------------------------------------------------------------ #
# R8 estimaciones alternativas de varios indicadores
if(TRUE){
# componentes de varianza, modelo solo con región
m3=
	survey::svyglm(
		formula=DNOR~factor(HV023)*BURB2,
		design=subset(s,HV007!=2024),family=gaussian
	)
m5=survey::svyglm(formula=DNOR~factor(HV023),design=subset(s,HV007!=2024),family=gaussian)
f=function(mm,nn){
	o=capture.output(aov(mm))
	u=(strsplit(gsub("\\s+"," ",trimws(o[5]))," "))
	v=(strsplit(trimws(gsub("\\s+"," ",substring(o[6:7],16,nchar(o[6]))))," "))
	p=
		tibble(
			trm=u[[1]],
			ssq=as.numeric(v[[1]]),
			dof=as.numeric(v[[2]])
		)
	p=
		bind_rows(
			p,
			tibble(trm="Total",ssq=sum(p$ssq),dof=sum(p$dof))
		)%>%
		mutate(msq=ssq/dof)
	p=
		p%>%
		mutate(
			pva=
				case_when(
					trm=="Total"~NA,
					trm=="Residuals"~msq,
					TRUE~(msq-p$msq[p$trm=="Residuals"])/nn
				)
		)
	return(p)
}
p=f(mm=m5,nn=median(LEST$R4$NNOP))
p$pva[p$trm=="Total"]=sum(p$pva[!p$trm%in%c("Total")])
p5=p%>%mutate(vco=pva/p$pva[p$trm=="Total"])
# componentes de varianza, modelo saturado con región y ámbito
p=f(mm=m3,nn=median(LEST$R4A$NNOP))
p$pva[p$trm=="BURB2"]=p$pva[p$trm=="BURB2"]/(p$dof[p$trm=="factor(HV023)"])
p$pva[p$trm=="factor(HV023)"]=p$pva[p$trm=="factor(HV023)"]/(p$dof[p$trm=="BURB2"])
p$pva[p$trm=="Total"]=sum(p$pva[!p$trm%in%c("Total")])
p3=p%>%mutate(vco=pva/p$pva[p$trm=="Total"])
# magnitud y dispersión de diferencia en prevalencias
r0=with(LEST$R4,{c(mean(DNOR),var(DNOR),sd(DNOR),sd(DNOR)/mean(DNOR))})
r1=survey::svymean(x=~DNOR,design=s);r2=confint(r1)
r3=survey::svyvar(x=~DNOR,design=s);r4=confint(r3)
r5=survey::svymean(x=~IANE4,design=s);r6=confint(r5)
r7=survey::svymean(x=~DCAM,design=s);r8=confint(r7)
s0=with(LEST$R4,{c(mean(DCAL),var(DCAL),sd(DCAL),sd(DCAL)/mean(DCAL))})
s1=survey::svymean(x=~DCAL,design=s);s2=confint(s1)
s3=survey::svyvar(x=~DCAL,design=s);s4=confint(s3)
z2=survey::svyglm(formula=DNOR~1,family=gaussian,design=s)
z3=survey::svyglm(formula=DCAM~1,family=binomial,design=s)
z4=survey::svyglm(formula=DCAL~1,family=gaussian,design=s)
r=
	tribble(
		~EVAL,~LVAL,~UVAL,~PVAL,~DIFE,~VERS,~INDI,
		as.numeric(r5),r6[1],r6[2],NA,"PAN4","1","Media Nacional Ponderada",
		as.numeric(r1),r2[1],r2[2],summary(z2)$coefficients[1,4],"DNOR","1","Media Nacional Ponderada",
		as.numeric(r3),r4[1],r4[2],NA,"DNOR","1","Varianza Nacional Ponderada",
		r0[1],NA,NA,NA,"DNOR","1","Media de Medias Regionales Ponderadas",
		r0[2],NA,NA,NA,"DNOR","1","Varianza entre Medias Regionales Ponderadas",
		r0[3],NA,NA,NA,"DNOR","1","Desviación E. de Medias Regionales Ponderadas",
		100*r0[4],NA,NA,NA,"DNOR","1","Coeficiente de Variación de Medias Regionales Ponderadas",
		r0[3]/as.numeric(r5),NA,NA,NA,"DNOR","1","Razón Desviación E. de Medias Regionales Ponderadas/Prevalencia Nacional Ponderada",
		r0[2]/as.numeric(r3),NA,NA,NA,"DNOR","1","Fracción de Varianza Regional/Total, DIV",
		p5$vco[p5$trm=="factor(HV023)"],NA,NA,NA,"DNOR","1","Fracción de Varianza Regional/Total, AOV",
		as.numeric(s1),s2[1],s2[2],summary(z4)$coefficients[1,4],"DCAL","1","Media Nacional Ponderada",
		as.numeric(s3),s4[1],s4[2],NA,"DCAL","1","Varianza Nacional Ponderada",
		s0[1],NA,NA,NA,"DCAL","1","Media de Medias Regionales Ponderadas",
		s0[2],NA,NA,NA,"DCAL","1","Varianza entre Medias Regionales Ponderadas",
		s0[3],NA,NA,NA,"DCAL","1","Desviación E. de Medias Regionales Ponderadas",
		100*s0[4],NA,NA,NA,"DCAL","1","Coeficiente de Variación de Medias Regionales Ponderadas",
		s0[3]/as.numeric(r5),NA,NA,NA,"DCAL","1","Razón Desviación E. de Medias Regionales Ponderadas/Prevalencia Nacional Ponderada",
		s0[2]/as.numeric(s3),NA,NA,NA,"DCAL","1","Fracción de Varianza Regional/Total, DIV",
		as.numeric(r7),r8[1],r8[2],summary(z3)$coefficients[1,4],"DCAM","1","Proporción de Falsos +/-, Nacional Ponderada"
	)
LEST$R8 =r 	# resumen de estimaciones de indicadores alternativos
rm(m3,m5,r0,r1,r2,r3,r4,r5,r6,r7,r8,s0,s1,s2,s3,s4,z2,z3,z4);gc()
print(date())
}
# ------------------------------------------------------------------------------------------------------------------------ #
# RMFIN modelos de selección final DNOR, DCAM
if(TRUE){
print(date())
y=
	d%>%
	select(DNOR,DCAM,HV007,HV023,BURB2,HV001,CASEID,W1RP,SID2)%>%
	mutate(HV007=factor(HV007))
x=survey::svydesign(ids=~HV001+CASEID,weights=~W1RP,strata=~SID2,data=y,nest=TRUE)
m1=
	survey::svyglm(
		formula=DNOR~factor(HV007)*factor(HV023)*BURB2,
		design=x,family=gaussian
	)
m2=
	survey::svyglm(
		formula=DCAM~factor(HV007)*factor(HV023)*BURB2,
		design=x,family=binomial
	)
m3=
	survey::svyglm(
		formula=
			DNOR~
			factor(HV023)+
			factor(HV023):factor(HV007)+
			factor(HV023):BURB2,
		design=x,family=gaussian
	)
m4=
	survey::svyglm(
		formula=
			DCAM~
			factor(HV007)+factor(HV023)+BURB2+
			factor(HV023):BURB2,
		design=x,family=binomial
	)
m5=survey::svyglm(formula=DNOR~factor(HV007),design=x,family=gaussian)
m6=survey::svyglm(formula=DNOR~factor(HV023),design=x,family=gaussian)
m7=survey::svyglm(formula=DCAM~factor(HV023),design=x,family=binomial)
m8=survey::svyglm(formula=DNOR~1,design=x,family=gaussian)
m9=survey::svyglm(formula=DCAM~1,design=x,family=binomial)
print(date())
save(m1,m2,m3,m4,m5,m6,m7,m8,m9,file="X2025010816.rda")
LEST$RMTER=
	bind_rows(
		broom::tidy(x=m1)%>%mutate(MOD="m1"),
		broom::tidy(x=m2)%>%mutate(MOD="m2"),
		broom::tidy(x=m3)%>%mutate(MOD="m3"),
		broom::tidy(x=m4)%>%mutate(MOD="m4"),
		broom::tidy(x=m5)%>%mutate(MOD="m5"),
		broom::tidy(x=m6)%>%mutate(MOD="m6"),
		broom::tidy(x=m7)%>%mutate(MOD="m7"),
		broom::tidy(x=m8)%>%mutate(MOD="m8"),
		broom::tidy(x=m9)%>%mutate(MOD="m9")
	)
LEST$RMRES=
	bind_rows(
		broom::glance(x=m1)%>%mutate(MOD="m1"),
		broom::glance(x=m2)%>%mutate(MOD="m2"),
		broom::glance(x=m3)%>%mutate(MOD="m3"),
		broom::glance(x=m4)%>%mutate(MOD="m4"),
		broom::glance(x=m5)%>%mutate(MOD="m5"),
		broom::glance(x=m6)%>%mutate(MOD="m6"),
		broom::glance(x=m7)%>%mutate(MOD="m7"),
		broom::glance(x=m9)%>%mutate(MOD="m9")
	)%>%
	mutate(
			MCFAR2=1-deviance/null.deviance
	)
r1=broom::tidy(x=m1)
r2=broom::tidy(x=m2)
s1=broom::glance(x=m1)
s2=broom::glance(x=m2)
o1=anova(object=m1)
o2=anova(object=m2)
LEST$RMFIN=
	list(
		M1=list(AOV=o1,TER=r1,MOD=s1),
		M2=list(AOV=o2,TER=r2,MOD=s2)
	)
print(date())
rm(m1,m2,m3,m4,m5,m6,m7,o1,o2,r1,r2,s1,s2,y,x);gc()
}
gc();print(date())
# archivo
save(d,s,R0,R1,R2,R3,R4,R5,R9,file="X2024030810.rda")
print(date())
}			# estp
# Producción de Tablas y Gráficos
if(TRUE){	# outc
LTAB=list()
LGRA=list()
# Tabla 1
b=
	LEST$RZ0%>%
	filter(VV007>=2009&VV007<=2023)%>%
	mutate(
		DE=format(DE,"%b"),
		HA=format(HA,"%b")
	)%>%
	select(VV007,NN44,NYA9,NDIN,DE,HA,CIC,MMU,DMU)%>%
	rename(
		Año=VV007,
		Totales=NN44,
		Elegibles=NYA9,
		Incluidos=NDIN,
		Desde=DE,
		Hasta=HA,
		Ciclo=CIC,
		Marco=MMU,
		Diseño=DMU
	)
K="Tabla 1"
J="Encuesta Demográfica y de Salud Familiar (ENDES)"
S=c(
	"Totales: Registrados en el Archivo ENDES",
	"Elegibles: Entre 6 y 35m (o sin edad) 2009-2023",
	"Incluidos: Entre 6-35m, con dato de Hb y Encuestado en Año",
	"CNPV: Censo Nacional de Población y Vivienda",
	"SISFOH: Sistema de Focalización de Hogares"
)
g=
	b%>%
	flextable::flextable()%>%
	flextable::add_header_row(values=c(paste0(K,": ",J)),colwidths=ncol(b))%>%
	flextable::add_footer_lines(S)
LTAB$T0101=g
# Tabla 2
l="%4.1f";o="%+4.1f"	# l="%5.3f";o="%+5.3f"
a=
	LEST$R0%>%
	mutate(across(IANE3:ud,~.*100))%>%
	mutate(
		PR3R=paste0(sprintf(l,IANE3)," (",sprintf(l,l3)," a ",sprintf(l,u3),")"),
		PR4R=paste0(sprintf(l,IANE4)," (",sprintf(l,l4)," a ",sprintf(l,u4),")"),
		PNOR=paste0(sprintf(o,DNOR)," (",sprintf(o,ld)," a ",sprintf(o,ud),")")
	)%>%
	mutate(across(PR3R:PNOR,~gsub("\\.",",",.)))%>%
	select(HV007,PR3R,PR4R,PNOR)%>%
	setNames(c(
		"Año",
		"Prev. Norma 2001",
		"Prev. Norma 2024",
		"Dif. Prev. 2001 - 2024"
	))
K="Tabla 2"
J="Estimaciones Anuales"
S=c(
	"Formato: Estimado [Límites Inferior a Superior de 95% de confianza]",
	"Prev: Prevalencia",
	"Dif: Diferencia entre Prevalencias Norma 2001 menos 2024"
)
g=
	a%>%
	flextable::flextable()%>%
	flextable::add_header_row(values=c(paste0(K,": ",J)),colwidths=ncol(a))%>%
	flextable::width(j=1,width=0.5)%>%
	flextable::width(j=2:ncol(a),width=2)%>%
	flextable::add_footer_lines(S)
LTAB$T0102=g
# Tabla 3
b=
	LEST$R4B%>%
	mutate(HV023=trimws(as.character(HV023)))%>%
	select(HV023,starts_with(c("PR3","PR4","DNOR","PCAM")))
l="%4.1f";o="%+4.1f";p="%5.3f"	# l="%5.3f";o="%+5.3f"
a=
	b%>%
	mutate(across(PR3:DNOR_upp,~.*100))%>%
	mutate(
		PR3R=paste0(sprintf(l,PR3)," (",sprintf(l,PR3_low)," a ",sprintf(l,PR3_upp),")"),
		PR4R=paste0(sprintf(l,PR4)," (",sprintf(l,PR4_low)," a ",sprintf(l,PR4_upp),")"),
		PNOR=paste0(sprintf(o,DNOR)," (",sprintf(o,DNOR_low)," a ",sprintf(o,DNOR_upp),")"),
		PCAR=paste0(sprintf(p,PCAM)," (",sprintf(p,PCAM_low)," a ",sprintf(p,PCAM_upp),")")
	)%>%
	mutate(across(PR3R:PCAR,~gsub("\\.",",",.)))%>%
	select(HV023,PR3R,PR4R,PNOR,PCAR)%>%
	setNames(c(
		"Región",
		"Prev. Norma 2001",
		"Prev. Norma 2024",
		"Dif. Prev. 2001 - 2024",
		"Prop. Cambio de 2001 a 2024"
	))
K="Tabla 3"
J="Estimaciones Regionales"
S=c(
	"Formato: Estimado [Límites Inferior a Superior de 95% de confianza]",
	"Prop: Proporción; Prev: Prevalencia",
	"Dif: Diferencia entre Prevalencias Norma 2001 menos 2024",
	"Cambio, PC: Proporción que cambian Diagnóstico entre Anemia y No Anemia"
)
g=
	a%>%
	flextable::flextable()%>%
	flextable::add_header_row(values=c(paste0(K,": ",J)),colwidths=ncol(a))%>%
	flextable::width(j=1,width=1.5)%>%
	flextable::width(j=2:5,width=2)%>%
	flextable::add_footer_lines(S)
LTAB$T0103=g
# Figura 1
y=
	bind_rows(
		LEST$R0%>%
		select(HV007,IANE3,se3,l3,u3)%>%
		setNames(c("HV007","IANE","SEM","LANE","UANE"))%>%
		mutate(NVER="2001")
	,
		LEST$R0%>%
		select(HV007,IANE4,se4,l4,u4)%>%
		setNames(c("HV007","IANE","SEM","LANE","UANE"))%>%
		mutate(NVER="2024")
	)%>%
	mutate(
		NVER=factor(x=NVER,levels=c("2024","2001"))
	)%>%
	filter(HV007%in%c(2009:2023))
g=
	ggplot(data=y)+
	geom_ribbon(mapping=aes(x=HV007,ymin=LANE,ymax=UANE,fill=NVER),alpha=0.25)+
	geom_line(mapping=aes(x=HV007,y=IANE,color=NVER))+
	scale_y_continuous(labels=scales::label_number(decimal.mark=","))+
	labs(
		x="año",y="prop. prevalencia anemia",color="norma",fill="norma",
		title="Figura 1 Tendencias de Prevalencia Nacional",
		caption=paste0("INEI/ENDES 6-35m"," n=",nrow(filter(d,HV007!=2024)))
	)+
	theme_minimal()
LGRA$G0101=g
# Figura 2
y=
	bind_rows(
		LEST$R9%>%
		select(FEDA3,FALT3,HV025,HV007,PR3,PR3_low,PR3_upp)%>%
		setNames(c("FEDA3","FALT3","HV025","HV007","IANE","LANE","UANE"))%>%
		mutate(NVER="2001")
	,
		LEST$R9%>%
		select(FEDA3,FALT3,HV025,HV007,PR4,PR4_low,PR4_upp)%>%
		setNames(c("FEDA3","FALT3","HV025","HV007","IANE","LANE","UANE"))%>%
		mutate(NVER="2024")
	)%>%
	mutate(
		HV025=
			factor(
				x=as.character(haven::as_factor(HV025)),
				levels=c("Urbano","Rural")
			),
		NVER=factor(x=NVER,levels=c("2024","2001"))
	)%>%
	filter(HV007%in%c(2009:2023))
g=
	ggplot(data=y)+
	facet_grid(rows=FALT3~FEDA3)+
	geom_ribbon(mapping=aes(x=HV007-2000,ymin=LANE,ymax=UANE,fill=NVER),color=NA,alpha=0.2,data=y%>%filter(HV025=="Urbano"))+
	geom_ribbon(mapping=aes(x=HV007-2000,ymin=LANE,ymax=UANE,fill=NVER),color=NA,alpha=0.1,data=y%>%filter(HV025=="Rural"))+
	geom_line(mapping=aes(x=HV007-2000,y=IANE,color=NVER,linetype=HV025))+
	labs(
		x="año, en el siglo XXI",y="prop. prevalencia anemia",
		color="norma",fill="norma",linetype="ámbito",
		title="Figura 2 Tendencias de Prevalencias Subnacionales",
		caption=paste0("INEI/ENDES 6-35m"," n=",nrow(filter(d,HV007!=2024)))
	)+
	theme_minimal()
LGRA$G0102=g
# Figura 3 (para RPMESP)
y=LEST$R4B
g=
	ggplot(data=y)+
	geom_abline(intercept=0,slope=1,color="gray",linewidth=1,linetype="solid")+
	geom_errorbar(mapping=aes(x=PR4,ymin=PR6_low,ymax=PR6_upp),color="pink")+
	geom_errorbarh(mapping=aes(y=PR6,xmin=PR4_low,xmax=PR4_upp),color="pink")+
	geom_point(mapping=aes(x=PR4,y=PR6),color="red")+
	annotate(x=0.475,y=0.475,geom="label",label="identidad",size=2.5,color="gray")+
	scale_x_continuous(labels=scales::label_number(decimal.mark=","))+
	scale_y_continuous(labels=scales::label_number(decimal.mark=","))+
	labs(
		x="prop. prevalencia anemia, norma 2024, fórmula",
		y="prop. prevalencia anemia, norma 2024 tabla",
		title="Figura 3 Prevalencias Regionales según técnica de cálculo",
		caption=
			paste0(
				"INEI/ENDES 6-35m 2009-2023",
				" n=",sum(y$NNOP)," p=",nrow(y)
			)
	)+
	theme_minimal()
LGRA$G0105=g
}			# outc
# ------------------------------------------------------------------------------------------------------------------------ #
# Funciones Diagnósticas (llamadas para suplemento GLM)
GSR6=function(mm,p,n=NDSIM){
	ff=as.character(mm$family)[1]
	if(ff=="binomial"){
		r=replicate(n,rbinom(n=length(p),size=1,prob=p))
	}else if(ff=="gaussian"){
		r=replicate(n,rnorm(n=length(p),mean=p,sd=sd(residuals(mm))))
	}else{
		r=rep(NA,n)
	}
	return(r)
}
GDX7=function(mm){
	ff=as.character(mm$family)[1]
	yy=as.character(mm$formula)[2]
	bckd=svydiags::svyCooksD(mobj=mm,stvar="IDESP",clvar="IDCLU",doplot=FALSE)
	bdff=svydiags::svydffits(mobj=mm,stvar="IDESP",clvar="IDCLU",z=3)
	bdfb=svydiags::svydfbetas(mobj=mm,stvar="IDESP",clvar="IDCLU",z=3)
	byha=svydiags::svyhat(mobj=mm,doplot=FALSE)
	bstr=svydiags::svystdres(mobj=mm,stvar="IDESP",clvar="IDCLU",doplot=FALSE)
	bvma=svydiags::Vmat(mobj=mm,stvar="IDESP",clvar="IDCLU")
	# diagnósticos svydiag: inflación de la varianza
	l=names(coefficients(mm))
	l=l[l!="(Intercept)"]
	l=gsub("FTEN2|FTEN3|FTEN4","FTEN",l)
	l=gsub("IDDOM2|IDDOM3","IDDOM",l)
	l=unique(l)
	l=paste0("~",paste(l,collapse="+"))
	bxmm=model.matrix(object=as.formula(l),data=mm$data)
	bvif=svydiags::svyvif(mobj=mm,X=bxmm[,-1],w=mm$data$WPOND,stvar="IDESP",clvar="IDCLU")
	#funcionaría solo en binomial, pendiente su resumen
	#bcio=svydiags::svycollinear(mod=mm,w=mm$data$WPOND,Vcov=vcov(mm),svyglm.obj=TRUE)
	w=
		tribble(
			~IPAR,~XVAL,~DSC,
			"NUOBS0",nrow(mm$data),"unweighted n",
			"MCFAR2",1-mm$deviance/mm$null.deviance,"McFadden Pseudo R2",
			"COOKMD",median(bckd),"Median Cook Influence",
			"COOKQ1",quantile(bckd,0.25),"Percentile 25 Cook",
			"COOKQ2",quantile(bckd,0.75),"Percentile 75 Cook",
			"COOKP2",mean(bckd>2),"Proportion Cook>2",
			"COOKP3",mean(bckd>3),"Proportion Cook>3",
			"FITSPX",mean(abs(bdff$Dffits)>bdff$cutoff),"Proportion Fit>cut",
			"BETAPX",mean(abs(bdfb$Dfbetas)>bdfb$cutoff),"Proportion Beta>cut",
			"LEVEP3",mean(byha>3),"Proportion Leverage >3",
			"RESIP3",mean(abs(bstr$stdresids)>3),"Proportion Residuals >3",
			"MCOVP0",mean(bvma!=0),"Proportion Covar Matrix non-zero"
		)
	W=
		tibble(
			TERM=labels(coefficients(mm)),
			TVAL=as.numeric(coefficients(mm)),
			BETX=apply(X=abs(bdfb$Dfbetas)>bdfb$cutoff,MARGIN=1,FUN=sum),
		)%>%
		left_join(
			y=
				bvif$`No intercept`%>%
				mutate(FGT3=svy.vif>3,TERM=rownames(bvif$`No intercept`)),
			by="TERM"
		)
	### $`Intercept adjusted`
	return(list(w=w,W=W))
}
GDX8=function(mm,NDSIM=30,FNSAM=1){
	ff=as.character(mm$family)[1]
	yy=as.character(mm$formula)[2]
	fc=mm$coefficients
	nn=as.integer(nrow(mm$data)*FNSAM)
	# diagnósticos DHARMa indirectos: residuos ponderados
	v=mm$data%>%slice_sample(n=nn,weight_by=W1RP,replace=TRUE)
	if(!any(is.na(fc))){
		p=predict(object=mm,newdata=v,type="response")
	}else{
		# preparación de expresiones para cada término
		fx=fc
		fx[is.na(fx)]=0
		l=names(fx)
		l=gsub("\\(Intercept\\)","1",l)
		l=gsub("\\)","\\)=='",l)
		l[!grepl(":",l)&grepl("factor",l)]=paste0(l[!grepl(":",l)&grepl("factor",l)],"'")
		l[grepl(":",l)&grepl(":factor",l)]=paste0(l[grepl(":",l)&grepl(":factor",l)],"')")
		l[grepl(":",l)&grepl("factor",l)]=gsub("factor","(factor",l[grepl(":",l)&grepl("factor",l)])
		l=gsub(":","')\\*",l)
		names(fx)=l
		l=paste0("(",l,")*(",as.numeric(fx),")")
		fl=paste(l,collapse="+")
		p=
			sapply(
				X=1:nrow(v),
				FUN=function(i){
					return(with(v[i,],eval(expr=parse(text=fl))))
				}
			)
		if(ff=="binomial"){p=exp(p)/(1+exp(p))}
	}
	u=eval(expr=parse(text=paste0("v$",yy)))
	s=
		DHARMa::createDHARMa(
			simulatedResponse=GSR6(mm=mm,p=p,n=NDSIM),
			fittedPredictedResponse=p,
			observedResponse=u,integerResponse=(ff=="binomial")
		)
	print(ggplot()+annotate(x=0.5,y=0.5,geom="label",label=paste(yy,ff))+theme_void())
	b1=DHARMa::testDispersion(simulationOutput=s,plot=TRUE)
	b2=DHARMa::testQuantiles(simulationOutput=s,plot=TRUE)
	b3=DHARMa::testUniformity(simulationOutput=s,plot=TRUE)
	b4=DHARMa::testOutliers(simulationOutput=s,plot=TRUE)
	o=
		tribble(
			~IPAR,~XVAL,~DSC,
			"PDISP1",b1$p.value,"p, Nonpar Dispersion test",
			"PQGAM2",b2$p.value,"p, Combined Adjusted Quantile test",
			"POSKS3",b3$p.value,"p, Asymptotic One-Sample Kolmogorov-Smirnov test",
			"POUTB4",b4$p.value,"p, Outlier Exact Binomial test",
			"PEXPE4",as.numeric(b4$null.value),"Expected Proportion of Outliers",
			"POBSE4",as.numeric(b4$estimate),"Observed Proportion of Outliers",
			"PLLOW4",as.numeric(b4$conf.int[1]),"Lower CL Proportion of Outliers",
			"PLUPP4",as.numeric(b4$conf.int[2]),"Upper CL Proportion of Outliers"
		)
	return(o)
}
GST0=function(ll,yv,bv){
	r=paste0(yv,"~0")
	z=
		tibble(
			SVLevel=ll,
			STTestP=
				sapply(
					X=ll,
					FUN=function(x){
						p=eval(expr=parse(text=paste0("subset(s,",bv,"==x)")))
						as.numeric(
							survey::svyttest(
								formula=as.formula(r),
								design=p
							)$p.value
						)
					}
				)
		)
	return(z)
}
# ------------------------------------------------------------------------------------------------------------------------ #
# Documentación
# Lista de variables
# Para cada niño se tomaron las siguientes variables_
# REC44.HW1    Edad en meses
# REC21.B4     Sexo declarado 
# RECH0.HV040  Altitud del conglomerado en metros
# RECH0.HV025  Ámbito urbano o rural
# RECH0.HV023  Región administrativa
# RECH0.HV007  Año de la entrevista 
# REC44.HW56   Hemoglobina en sangre
# Además se tomaron variables del diseño muestral:
# RECH0.HV022  Estrato
# RECH0.HV001  Conglomerado
# RECH0.HHID   Vivienda, Hogar
# REC44.CASEID Vivienda, Hogar, Madre (y REC21)
# REC44.HWIDX  Sujeto (y REC21)
# RECH0.HV005  Factor de Expansión
# Enlaces:
# RECH0 ---< REC44 --- REC21			HHID(CASEID) -< HWIDX
# Salidas:
# LEST  	Estimaciones
#	RY0 	Descripción de la Inclusión por Regiones
#	RZ0 	Descripción de la Muestra por Años, Antes de Exclusión
#	R0  	Estimaciones Nacionales
#	R1  	Estimaciones por grupo de edad
#	R2  	Estimaciones por dominio
#	R3  	Estimaciones por dominio-año
#	R4  	Estimaciones por región-año
#	R4A 	Estimaciones por región ámbito
#	R4B 	Estimaciones por región
#	R4C 	Estimaciones por región-ámbito-año
#	R4D 	Identificación de regiones extremas
#	R5  	Estimaciones por grupo de altitud
#	R8  	Estimaciones de indicadores
#	R9  	Estimaciones por altitud-ámbito-año
#	RMFIN	Modelos Finales (saturados)
#	RMRES	Modelos Finales - resumenes
#	RMTER	Modelos Finales - términos
# LTAB	Tablas
#	T0101	Encuesta Demográfica y de Salud Familiar
#	T0102	Prevalencia nacional de anemia, anual
#	T0103	Prevalencia nacional de anemia, regional
# LGRA	Gráficos
#	G0101	Tendencias de prevalencia nacional
#	G0102	Tendencias de prevalencias subnacionales
#	G0103	Prevalencias por región-año según normas
#	G0104	Prevalencias por región-años según OMS 2024
#	G0105	Prevalencias regionales según técnica de cálculo
# ------------------------------------------------------------------------------------------------------------------------ #
# License:
#
# The data sources for this analysis come from publications and data by 
# the Instituto Nacional de Estadística e Informática (INEI) from Peru, 
# which can be freely obtained at https://proyectos.inei.gob.pe/microdatos/ 
# and https://www.datosabiertos.gob.pe/ under a ODC Open Database License.
# They can also be freely obtained from https://dhsprogram.com/Data/ . 
# Consolidated and anonymized data, as used for the analysis, 
# are freely available in github/vipermcs.
#
# This R program has been developed by Miguel Campos, 
# on the basis of discussion with the co-authors.
# It is placed freely available, with the sole condition of quoting the source.
# Copyright (c) 2024 Miguel Campos under MIT License
# 
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
# 
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
# ------------------------------------------------------------------------------------------------------------------------ #
