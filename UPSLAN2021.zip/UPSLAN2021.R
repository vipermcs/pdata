# UPSLAN2021.R (NMWorks.R) 2021-Set-05 vipermcs@gmail.com & mymirandac@gmail.com
# ------------------------------------------------------------------------------------------------------------------------ #
# Inicialización
require(tidyverse)
windows(width=6,height=6,record=T)
options(digits=5,width=240)
options(survey.lonely.psu="adjust")
options(dplyr.summarise.inform=FALSE,dplyr.show_progress=FALSE)
PCRIT = 0.05
ZCRIT = qnorm(1-PCRIT/2)
ALPHA = PCRIT
date()
# ======================================================================================================================== #
# 2021-May-28 Ultraprocesados
# Tabulación
R0="Z:/"
T0="2021090206"
load(file="Z:/UPSLAN2021.rda")
setwd(R0)
# cálculo preliminar
S=list(SPOOL,P)
T=c("INS/CENAN VIANEV 2015-2016","INS/CENAN MONIN 2008-2010")
G=list()
U=list()
for(k in 1:length(S)){
	s=srvyr::as_survey_design(S[[k]])%>%filter(!is.na(ENERCX))
	w=
		bind_rows(
			s%>%
			mutate(GRP="T")%>%
			group_by(GRP)%>%
			summarize(
				RE1=srvyr::survey_ratio(numerator=ENERC1,denominator=ENERCX,na.rm=TRUE,vartype=c("se","ci")),
				RE2=srvyr::survey_ratio(numerator=ENERC2,denominator=ENERCX,na.rm=TRUE,vartype=c("se","ci")),
				RE3=srvyr::survey_ratio(numerator=ENERC3,denominator=ENERCX,na.rm=TRUE,vartype=c("se","ci")),
				RE4=srvyr::survey_ratio(numerator=ENERC4,denominator=ENERCX,na.rm=TRUE,vartype=c("se","ci")),
				NNIN=srvyr::unweighted(n())
			)%>%
			mutate(TAB="A:Total")
		,
			s%>%
			filter(SEX%in%c(1:2))%>%
			mutate(GRP=c("1:M","2:F")[SEX])%>%
			group_by(GRP)%>%
			summarize(
				RE1=srvyr::survey_ratio(numerator=ENERC1,denominator=ENERCX,na.rm=TRUE,vartype=c("se","ci")),
				RE2=srvyr::survey_ratio(numerator=ENERC2,denominator=ENERCX,na.rm=TRUE,vartype=c("se","ci")),
				RE3=srvyr::survey_ratio(numerator=ENERC3,denominator=ENERCX,na.rm=TRUE,vartype=c("se","ci")),
				RE4=srvyr::survey_ratio(numerator=ENERC4,denominator=ENERCX,na.rm=TRUE,vartype=c("se","ci")),
				NNIN=srvyr::unweighted(n())
			)%>%
			mutate(TAB="B:Sexo")
		,
			s%>%
			filter(!is.na(EDM))%>%
			mutate(GEDAD=case_when(EDM>=0&EDM<12~9,EDM>=12&EDM<24~18,EDM>=24&EDM<36~30))%>%
			mutate(GRP=as.character(factor(GEDAD,levels=c(9,18,30),labels=c("06-11","12-23","24-35"))))%>%
			filter(!is.na(GRP)&GRP!="NA")%>%
			group_by(GRP)%>%
			summarize(
				RE1=srvyr::survey_ratio(numerator=ENERC1,denominator=ENERCX,na.rm=TRUE,vartype=c("se","ci")),
				RE2=srvyr::survey_ratio(numerator=ENERC2,denominator=ENERCX,na.rm=TRUE,vartype=c("se","ci")),
				RE3=srvyr::survey_ratio(numerator=ENERC3,denominator=ENERCX,na.rm=TRUE,vartype=c("se","ci")),
				RE4=srvyr::survey_ratio(numerator=ENERC4,denominator=ENERCX,na.rm=TRUE,vartype=c("se","ci")),
				NNIN=srvyr::unweighted(n())
			)%>%
			mutate(TAB="C:Edad")
		,
			s%>%
			mutate(GRP=c("1:Lim","2:Urb","3:Rur")[as.numeric(IDDOM)])%>%
			group_by(GRP)%>%
			summarize(
				RE1=srvyr::survey_ratio(numerator=ENERC1,denominator=ENERCX,na.rm=TRUE,vartype=c("se","ci")),
				RE2=srvyr::survey_ratio(numerator=ENERC2,denominator=ENERCX,na.rm=TRUE,vartype=c("se","ci")),
				RE3=srvyr::survey_ratio(numerator=ENERC3,denominator=ENERCX,na.rm=TRUE,vartype=c("se","ci")),
				RE4=srvyr::survey_ratio(numerator=ENERC4,denominator=ENERCX,na.rm=TRUE,vartype=c("se","ci")),
				NNIN=srvyr::unweighted(n())
			)%>%
			mutate(TAB="D:Ámbito")
		,
			s%>%
			mutate(GRP=as.character(ifelse(IDENC=="VN15",2015,ifelse(IDENC=="VN16",2016,lubridate::year(FENT)))))%>%
			group_by(GRP)%>%
			summarize(
				RE1=srvyr::survey_ratio(numerator=ENERC1,denominator=ENERCX,na.rm=TRUE,vartype=c("se","ci")),
				RE2=srvyr::survey_ratio(numerator=ENERC2,denominator=ENERCX,na.rm=TRUE,vartype=c("se","ci")),
				RE3=srvyr::survey_ratio(numerator=ENERC3,denominator=ENERCX,na.rm=TRUE,vartype=c("se","ci")),
				RE4=srvyr::survey_ratio(numerator=ENERC4,denominator=ENERCX,na.rm=TRUE,vartype=c("se","ci")),
				NNIN=srvyr::unweighted(n())
			)%>%
			mutate(TAB="F:Periodo")
		)
	y=
		w%>%
		pivot_longer(RE1:RE4_upp)%>%
		mutate(
			FRC=substr(name,3,3),
			name=case_when(
				grepl("NIN",name)~"NNI",
				grepl("se", name)~"SEM",
				grepl("low",name)~"LOW",
				grepl("upp",name)~"UPP",
				TRUE~"EST"
			)
		)%>%
		pivot_wider()%>%
		mutate(CAT=paste(TAB,GRP))
	g=
		ggplot(data=y%>%filter(!is.na(EST)))+
		geom_col(mapping=aes(x=CAT,y=EST,fill=FRC))+
		geom_errorbar(mapping=aes(x=CAT,ymin=LOW,ymax=UPP),width=0.25,data=y%>%filter(!is.na(EST)&FRC==4))+
		scale_fill_manual(name="Procesado (NOVA)",labels=paste(c("Mínimo/No","Ingredientes","Alimentos","Ultra"),"procesados"),values=colorspace::diverge_hcl(4))+
		labs(x="Grupo",y="Proporción de Energía",title="Ingesta de Alimentos Perú 6-35m",subtitle=T[k])+
		coord_flip()+
		theme_minimal()+
		theme(axis.text.y=element_text(hjust=0),legend.text=element_text(size=8))
	U[[k]]=w
	G[[k]]=g
}
pdf(file=paste0("X",T0,"nova.pdf"),paper="a4")
#png(filename=paste0("X",T0,"nova","%01d",".png"),width=1600,height=1600,units="px",res=300,pointsize=10)
print(G[[1]])
print(G[[2]])
dev.off()
openxlsx::write.xlsx(
	x=list(VIANEV=U[[1]],MONIN=U[[2]]),
	file=paste0("X",T0,"nova.xlsx")
)
# ======================================================================================================================== #
