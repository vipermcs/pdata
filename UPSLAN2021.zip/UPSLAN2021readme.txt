UPSLAN2021readme.txt

Short documentation for 

Miranda & Campos
Contribución energética de alimentos procesados y ultraprocesados en la dieta de niños peruanos
SLAN 2021

This ZIP file contains the data processing files:

UPSLAN2021.rda        study dataset for MONIN & VIANEV children
UPSLAN2021.R          source code for producing the presentation results, can run
UPSLAN2021load.txt    source code for original data load and building study dataset, just for documentation

Questions & Comments: mymirandac@gmail.com & vipermcs@gmail.com
