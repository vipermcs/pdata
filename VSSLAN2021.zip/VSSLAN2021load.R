# VSSLAN2021.R (NMWorks.R) 2021-Set-05 vipermcs@gmail.com & mymirandac@gmail.com
# ------------------------------------------------------------------------------------------------------------------------ #
# Inicialización
require(tidyverse)
Sys.setenv("R_ZIPCMD"=paste0(path.expand('~'),"/Tools/Rtools/bin/zip.exe"))
Sys.setenv(RSTUDIO_PANDOC="C:/Users/Usuario/Documents/Tools/pandoc/")
windows(width=6,height=6,record=T)
options(digits=5,width=240)
options(survey.lonely.psu="adjust")
options(dplyr.summarise.inform=FALSE,dplyr.show_progress=FALSE)
PCRIT = 0.05
ZCRIT = qnorm(1-PCRIT/2)
ALPHA = PCRIT
DSRCP = "X:\\"
DSRCI = "Z:\\"
DTABS = "X:\\Tabs\\"	# DTABS="Z:\\"
WKDIR = "X:\\Work\\"
WKOUT = "X:\\Tasks\\NMWorks\\nmdrafts\\"
setwd(DSRCI)	# WKDIR
source(paste(DTABS,"VipeRLib.R",sep=""))
load(paste(DTABS,"NuTabs.rda",sep=""))
load(paste(DTABS,"GCTabs.rda",sep=""))
load(paste(DTABS,"PETabs.rda",sep=""))
date()
# ======================================================================================================================== #
# 2021-Jul-08 ENDES vs SIEN (agregado)
# Carga
print(date())
SR0="191 183  86 170"	# https://www.random.org/cgi-bin/randbyte?nbytes=4&format=d 2021-Jul-09 08:32
x=prod(as.numeric(unlist(strsplit(SR0,"\\s+"))));set.seed(x)
# informes SIEN niños 2014-2020
F2=function(f,h,r){
if(grepl("Y",r)){
	s=
		c(
			"DPTO",
			"DTE2N","DTE2C","DTE2P",
			"XD1","DTE1N","DTE1C","DTE1P",
			"XD2","DPE2N","DPE2C","DPE2P",
			"XD3","NPT2N",
			"DPT2C","DPT2P",
			"XD4","XN4","SPT1C","SPT1P",
			"XD5","XN5","OPT2C","OPT2P"
		)
	l=
		c(
			"text",
			"numeric","numeric","numeric",
			"skip","numeric","numeric","numeric",
			"skip","numeric","numeric","numeric",
			"skip","numeric",
			"numeric","numeric",
			"skip","skip","numeric","numeric",
			"skip","skip","numeric","numeric"
		)
}else if(grepl("Q",r)){
	s=
		c(
			"DPTO",
			"DTE2N","DTE2C","DTE2P",
			"DTE1C","DTE1P",
			"DPE2N","DPE2C","DPE2P",
			"NPT2N",
			"DPT2C","DPT2P",
			"SPT1C","SPT1P",
			"OPT2C","OPT2P"
		)
	l=c("text",rep("numeric",15))
}else if(grepl("P",r)){
	s=
		c(
			"DPTO","PROV","DIST",
			"DTE2N","DTE2C","DTE2P",
			"DPE2N","DPE2C","DPE2P",
			"NPT2N",
			"DPT2C","DPT2P",
			"SPT1C","SPT1P",
			"OPT2C","OPT2P"
		)
	l=c(rep("text",3),rep("numeric",13))
}else{
	s=
		c(
			"DPTO",
			"DTE2N","DTE2C","DTE2P",
			"DTE1N","DTE1C","DTE1P",
			"DPE2N","DPE2C","DPE2P",
			"NPT2N",
			"DPT2C","DPT2P",
			"SPT1C","SPT1P",
			"OPT2C","OPT2P"
		)
	l=c("text",rep("numeric",3*3+1+3*2))
}
d=readxl::read_excel(path=f,sheet=h,range=r,col_names=s,col_types=l)
if(grepl("Q",r)){d=d%>%mutate(DTE1N=DTE2N)}
return(d)
}
dSIEN=
	bind_rows(
		F2(
			f="X:/Tabs/CENAN/SIEN/2a_SIEN_Indicadores nutricionales nivel distrital Perú 2014_niños_OMS.xls",
			h="0-59",r="A16:P1861"
		)%>%
		group_by(DPTO)%>%
		summarize(
			DTE2N=sum(DTE2N,na.rm=TRUE),
			DTE2C=sum(DTE2C,na.rm=TRUE),
			DPE2N=sum(DPE2N,na.rm=TRUE),
			DPE2C=sum(DPE2C,na.rm=TRUE),
			NPT2N=sum(NPT2N,na.rm=TRUE),
			DPT2C=sum(DPT2C,na.rm=TRUE),
			SPT1C=sum(SPT1C,na.rm=TRUE),
			OPT2C=sum(OPT2C,na.rm=TRUE)
		)%>%
		mutate(
			DTE2P=100*DTE2C/DTE2N,
			DPE2P=100*DPE2C/DPE2N,
			DPT2P=100*DPT2C/NPT2N,
			SPT1P=100*SPT1C/NPT2N,
			OPT2P=100*OPT2C/NPT2N
		)%>%
		mutate(PERIO=2014,FUENT="SIEN"),
		F2(
			f="X:/Tabs/CENAN/SIEN/2_Indicadores Nios Enero-Diciembre 2015.xlsx",
			h="EN_0-59 m x Dpto",r="B14:R39"
		)%>%
		mutate(PERIO=2015,FUENT="SIEN"),
		F2(
			f="X:/Tabs/CENAN/SIEN/Indicadores Ninos Ene-Dic 2016.xlsx",
			h="E.N. 0-59m Dpto",r="B13:R38"
		)%>%
		mutate(PERIO=2016,FUENT="SIEN"),
		F2(
			f="X:/Tabs/CENAN/SIEN/Indicadores Ninos 2017 Ene-Dic-V5.xlsx",
			h="EN 0-59m x DEP",r="B8:Y33"
		)%>%
		mutate(PERIO=2017,FUENT="SIEN"),
		F2(
			f="X:/Tabs/CENAN/SIEN/indicadores_ninos_enero_diciembre_2018.xlsx",
			h="EN 0-59m x DEP",r="B8:Y33"
		)%>%
		mutate(PERIO=2018,FUENT="SIEN"),
		F2(
			f="X:/Tabs/CENAN/SIEN/indicadores_ninos_enero_diciembre_2019.xlsx",
			h="EN 0-59m x DEP",r="B8:Y33"
		)%>%
		mutate(PERIO=2019,FUENT="SIEN"),
		F2(
			f="X:/Tabs/CENAN/SIEN/indicadores_ninos_enero_diciembre_2019_base_datos_his_minsa.xlsx",
			h="EN 0-59m x DEP",r="B8:Q33"
		)%>%
		mutate(PERIO=2019,FUENT="HIS"),
		F2(
			f="X:/Tabs/CENAN/SIEN/1.Indic Ninos  Enero_Diciembre SIEN 2020.xlsx",
			h="EN 0-59m x DEP",r="B8:Q33"
		)%>%
		mutate(PERIO=2020,FUENT="SIEN"),
		F2(
			f="X:/Tabs/CENAN/SIEN/A.Indic. Niños a Dic 2020.xlsx",
			h="EN 0-59m x DEP",r="B8:Q33"
		)%>%
		mutate(PERIO=2020,FUENT="HIS")
	)
# proyecciones poblacionales INEI
x=
	TPPBE37%>%
	filter(GSX=="T"&GYR>=2010)%>%
	select(DPTO,GYR,TOTAL,A00)%>%
	rename(PERIO=GYR)%>%
	mutate(
		DPTO=iconv(DPTO,"UTF8","ASCII//TRANSLIT")
	)%>%
	mutate(
		CDPTO=
			case_when(
				DPTO=="Total"~"PE",
				DPTO=="Callao"~"CO",
				DPTO=="Huanuco"~"HO",
				DPTO=="Lambayeque"~"LE",
				TRUE~substr(toupper(DPTO),1,2)
			)
	)
z=tibble(PERIO=2014:2020)
y=
	x%>%
	group_by(CDPTO)%>%
	do(
		MODP=lm(TOTAL~poly(PERIO,3),data=.),
		MODN=lm(A00~poly(PERIO,3),data=.)
	)%>%
	mutate(PRED=NA)
for(i in 1:nrow(y)){
	y$PRED[i]=
		list(
			tibble(
				PREP=predict(y$MODP[[i]],newdata=z),
				PREN=predict(y$MODN[[i]],newdata=z),
				PERIO=z$PERIO,
				CDPTO=y$CDPTO[i]
			)
		)
}
zBE37=do.call(rbind,y$PRED)
# ENDES informes PPR - versión actualizada EPPR en PETabs.rda, parche 2014 de informe endes
X=pdftools::pdf_text(pdf="E:\\Lib\\Pub\\Peru\\INEI\\BibINEI\\ENDES\\ENDES 2014.pdf")
y=(X[312]%>%readr::read_lines())[21:47]
x=
	tibble(x=(gsub("(\\d)\\s(\\d)","\\1\\2",gsub(",",".",y))))%>%
	separate(col=x,sep=seq(50,170,20),into=c("DPTO","DTES","DTET","DPTS","DPTT","DPES","DPET","NSAM"))%>%
	mutate(across(DPTO:NSAM,trimws))%>%
	mutate(across(DTES:NSAM,as.numeric))
xEPPR=
	bind_rows(
		EPPR,
		x%>%
		select(DPTO,DTET,NSAM)%>%
		mutate(Tramo="2014",Grupo="RegionP",Indic="DTE06",Ciclo=4,Perio=2014,Punto=2014.5,DS=as.numeric(NA),NP=as.numeric(NA))%>%
		rename(Categ=DPTO,VE=DTET,NS=NSAM)
	)%>%
	filter(
		Indic=="DTE06"&
		substr(Tramo,2,2)=="0"&
		Grupo%in%c("Total","RegionP")&
		!Categ%in%c(
			"Lima y Callao",
			"Prov. Const. del Callao",
			"Provincia de Lima 2/","Provincia de Lima 5/",
			"Lima Provincias 6/",
			"Región Lima 3/"
		)
	)%>%
	mutate(
		DPTO=ifelse(Categ=="Total","PERU",iconv(toupper(Categ),"UTF8","ASCII//TRANSLIT"))
	)%>%
	mutate(
		CDPTO=
			case_when(
				DPTO=="CALLAO"~"CO",
				DPTO=="HUANUCO"~"HO",
				DPTO=="LAMBAYEQUE"~"LE",
				TRUE~substr(DPTO,1,2)
			),
		PDTE5E=VE/100,
		SDTE5E=DS/100,
		NDTE5E=NS
	)%>%
	rename(PERIO=Perio)
# tabla de regiones
rEPPR=
	EPPR%>%
	filter(
		substr(Tramo,1,2)%in%c("2B","2X")&
		Grupo=="RegionP"&
		Indic=="DTE06"&
		!Categ%in%c(
			"Lima y Callao",
			"Prov. Const. del Callao",
			"Provincia de Lima 2/","Provincia de Lima 5/",
			"Lima Provincias 6/",
			"Región Lima 3/"
		)
	)%>%
	mutate(
		DPTO=ifelse(Categ=="Total","PERU",iconv(toupper(Categ),"UTF8","ASCII//TRANSLIT"))
	)%>%
	mutate(
		CDPTO=
			case_when(
				DPTO=="CALLAO"~"CO",
				DPTO=="HUANUCO"~"HO",
				DPTO=="LAMBAYEQUE"~"LE",
				TRUE~substr(DPTO,1,2)
			),
		PDTE5E=VE/100,
		SDTE5E=DS/100,
		NDTE5E=NS
	)%>%
	rename(PERIO=Perio)%>%
	group_by(CDPTO,DPTO)%>%
	summarize(PLEX=mean(VE,na.rm=TRUE)/100)
# reunión para comparación de prevalencias
d=
	dSIEN%>%
	mutate(
		DPTO=iconv(DPTO,"UTF8","ASCII//TRANSLIT")
	)%>%
	mutate(
		CDPTO=
			case_when(
				DPTO=="CALLAO"~"CO",
				DPTO=="HUANUCO"~"HO",
				DPTO=="LAMBAYEQUE"~"LE",
				TRUE~substr(DPTO,1,2)
			),
		PDTE5=DTE2P/100
	)
wEVSS=
	d%>%
	select(PERIO,FUENT,CDPTO,DPTO,PDTE5,DTE2N)%>%
	left_join(
		y=xEPPR%>%select(PERIO,CDPTO,PDTE5E,SDTE5E,NDTE5E),
		by=c("PERIO","CDPTO")
	)%>%
	left_join(
		y=zBE37,
		by=c("PERIO","CDPTO")
	)%>%
	mutate(
		DSIEN=PDTE5-PDTE5E,
		WENDE=ZCRIT*SDTE5E,
		CSIEN=DTE2N/PREN,
		WT1=1,
		ID1=row_number()
	)%>%
	labelled::set_variable_labels(
		PERIO	="Año Calendario",
		FUENT	="Fuente de Registro",
		CDPTO	="Código del Departamento",
		DPTO	="Departamento",
		PDTE5	="Prevalencia SIEN",
		DTE2N	="Atenciones 0-59m SIEN",
		PDTE5E	="Prevalencia ENDES",
		SDTE5E	="Error Estándar ENDES",
		NDTE5E	="Niños (s/ponderar) ENDES",
		PREP	="Población Total Proyectada INEI",
		PREN	="Población 0-59m Proyectada INEI",
		DSIEN	="Diferencia SIEN-ENDES",
		WENDE	="Márgen de Error 95% ENDES",
		CSIEN	="Concentración Aparente SIEN",
		WT1 	="Ponderación (1)",
		ID1 	="Número de Fila"
	)
pEVSS=survey::svydesign(ids=~1,weights=~WT1,data=wEVSS)
# modelamiento
d=wEVSS%>%filter(FUENT=="SIEN"&!is.na(PDTE5E))
MCLN1=lm(formula=PDTE5~PDTE5E,data=d%>%filter(CDPTO=="PE"))
MCLR1=lm(formula=PDTE5~PDTE5E,data=d%>%filter(CDPTO!="PE"))
MCMR0=lme4::lmer(formula=PDTE5~PDTE5E+(1|CDPTO),data=d%>%filter(CDPTO!="PE"))
MCMR1=lme4::lmer(formula=PDTE5~PDTE5E+(1+PDTE5E|CDPTO),data=d%>%filter(CDPTO!="PE"))
# simulación simple
dSSIM=
	crossing(LSIZ=1000*10^(1:3),BCOE=c(-0.010,-0.005,0.015),ACOE=c(0.1,0.2,0.3))%>%
	mutate(ACOE=ACOE+1/log10(LSIZ)/10,IDEP=sprintf("%02d",row_number()))%>%
	labelled::set_variable_labels(
		LSIZ	="Tamaño de Población",
		BCOE	="Cambio en Prevalencia según Tiempo",
		ACOE	="Nivel Basal de Prevalencia",
		IDEP	="Código de Región"
	)
v=crossing(IDEP=dSSIM$IDEP,IDYR=2015:2020)
v=v%>%left_join(y=dSSIM,by="IDEP")%>%mutate(PREV=ACOE+BCOE*(IDYR-2015))
# para cada item en v sacar 30 muestras pares endes y sien
print(date())
for(i in 1:nrow(v)){
	#print(i)
	K=v$LSIZ[i]/1000
	P=v$PREV[i]
	n=round(ifelse(K==1000,3000,1000)/1.5,0)
	m=ifelse(K==1000,600000,ifelse(K==100,60000,9000))
	for(j in 1:30){
		x=mean(rbinom(n,1,P))
		y=mean(rbinom(m,1,P))
		u=tibble(ISEQ=i,JSEQ=j,IDEP=v$IDEP[i],IDYR=v$IDYR[i],PREV=P,PREN=K*1000,NEND=n,NSIE=m,PEND=x,PSIE=y)
		if(i==1&j==1){D=u}else{D=bind_rows(D,u)}
	}
}
print(date())
vSSIM=
	v%>%
	labelled::set_variable_labels(
		PREV	="Prevalencia Verdadera",
		IDYR	="Año",
		IDEP	="Región"
	)
rSSIM=
	D%>%
	labelled::set_variable_labels(
		ISEQ	="Código de Escenario Región-Año",
		JSEQ	="Código de Muestra Replicada",
		PREV	="Prevalencia Verdadera",
		PREN	="Tamaño de Población, miles",
		NEND	="Tamaño de Muestra de Encuesta",
		NSIE	="Tamaño de 'Muestra' de Registro",
		PEND	="Prevalencia Observada en Encuesta",
		PSIE	="Prevalencia Observada en Registro",
		IDYR	="Año",
		IDEP	="Región"
	)
S=sum(dSSIM$LSIZ)
xSSIM=
	rSSIM%>%
	left_join(y=dSSIM,by="IDEP")%>%
	group_by(JSEQ,IDYR)%>%
	summarize(PREV=sum(PREV*LSIZ)/S,PEND=sum(PEND*LSIZ)/S,PSIE=sum(PSIE*LSIZ)/sum(d$LSIZ))%>%
	labelled::set_variable_labels(
		PREV	="Prevalencia Nacional Verdadera",
		PEND	="Prevalencia Nacional Observada en Encuesta",
		PSIE	="Prevalencia Nacional Observada en Registro"
	)
# simulación realista
y=
	wEVSS%>%
	filter(FUENT=="SIEN"&!is.na(PDTE5E))%>%
	rename(IDYR=PERIO,IDEP=CDPTO,PREV=PDTE5E)
d=y%>%filter(IDEP!="PE")
M=lme4::lmer(formula=PREV~IDYR+(1+IDYR|IDEP),data=d)
G=lm(formula=PDTE5~PREV,data=d)
H=lme4::lmer(formula=PDTE5~PREV+(1+PREV|IDEP),data=d)
#x=as.numeric(coefficients(G));S=x[2];E=1-x[1]
x=as.numeric(lme4::fixef(H));S=x[2];E=1-x[1]
v=
	d%>%
	mutate(PREV=predict(object=M,newdata=d))%>%
	left_join(y=zBE37%>%rename(IDEP=CDPTO,IDYR=PERIO,LSIZ=PREN),by=c("IDEP","IDYR"))%>%
	select(IDEP,IDYR,LSIZ,PREV)
print(date())
for(i in 1:nrow(v)){
	#print(i)
	K=v$LSIZ[i]
	P=v$PREV[i]
	n=round(ifelse(v$IDEP[i]=="LI",3000,1000)/1.5,0)
	m=round(10^(log10(K)*0.916+0.314),0)
	for(j in 1:30){
		X=rbinom(n,1,P)
		Y=rbinom(m,1,P)
		x=mean(X)
		y=mean(Y)
		Z=c(rbinom(round(y*m),1,S),rbinom(m-round(y*m),1,1-E))
		z=mean(Z)
		u=
			tibble(
				ISEQ=i,JSEQ=j,IDEP=v$IDEP[i],IDYR=v$IDYR[i],
				PREV=P,PREN=K,NEND=n,NSIE=m,
				PEND=x,PSIE=y,PSIX=z
			)
		if(i==1&j==1){D=u}else{D=bind_rows(D,u)}
	}
}
print(date())
mSMED=M
gSMED=G
hSMED=H
vSMED=
	v%>%
	labelled::set_variable_labels(
		PREV	="Prevalencia Verdadera",
		IDYR	="Año",
		IDEP	="Región"
	)
rSMED=
	D%>%
	labelled::set_variable_labels(
		ISEQ	="Código de Escenario Región-Año",
		JSEQ	="Código de Muestra Replicada",
		PREV	="Prevalencia Verdadera",
		PREN	="Tamaño de Población, miles",
		NEND	="Tamaño de Muestra de Encuesta",
		NSIE	="Tamaño de 'Muestra' de Registro",
		PEND	="Prevalencia Observada en Encuesta",
		PSIE	="Prevalencia Observada en Registro",
		PSIX	="Prevalencia Observada en Registro, con Error",
		IDYR	="Año",
		IDEP	="Región"
	)
xSMED=
	rSMED%>%
	left_join(y=vSMED%>%select(IDEP,IDYR,LSIZ),by=c("IDEP","IDYR"))%>%
	left_join(y=vSMED%>%group_by(IDYR)%>%summarize(TSIZ=sum(LSIZ)),by="IDYR")%>%
	group_by(JSEQ,IDYR)%>%
	summarize(PREV=sum(PREV*LSIZ/TSIZ),PEND=sum(PEND*LSIZ/TSIZ),PSIE=sum(PSIE*LSIZ/TSIZ))%>%
	labelled::set_variable_labels(
		PREV	="Prevalencia Nacional Verdadera",
		PEND	="Prevalencia Nacional Observada en Encuesta",
		PSIE	="Prevalencia Nacional Observada en Registro"
	)
# archivo
save(
	list=c(
		"wEVSS","pEVSS","xEPPR","rEPPR","zBE37",
		"dSSIM","vSSIM","rSSIM","xSSIM",
		"mSMED","gSMED","hSMED","vSMED","rSMED","xSMED",
		"MCLN1","MCLR1","MCMR0","MCMR1"
	),
	file="X:/Tasks/NMWorks/nmdrafts/SIENVS.rda"
)
print(date())
# ======================================================================================================================== #
