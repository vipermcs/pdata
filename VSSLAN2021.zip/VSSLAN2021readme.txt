VSSLAN2021readme.txt

Short documentation for 

Campos & Miranda
Prevalencia de Desnutrición Crónica: Encuesta Nacional Continua vs Sistemas de Información
SLAN 2021

This ZIP file contains the data processing files:

VSSLAN2021.rda        study dataset with national and regional estimates from ENDES & HIS/SIEN
VSSLAN2021.R          source code for producing the presentation results, can run
VSSLAN2021load.txt    source code for original data load and building study dataset, just for documentation

Questions & Comments: mymirandac@gmail.com & vipermcs@gmail.com
