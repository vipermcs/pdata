# VSSLAN2021.R (NMWorks.R) 2021-Set-05 vipermcs@gmail.com & mymirandac@gmail.com
# ------------------------------------------------------------------------------------------------------------------------ #
# Inicialización
require(tidyverse)
options(dplyr.summarise.inform=FALSE,dplyr.show_progress=FALSE)
PCRIT = 0.05
ZCRIT = qnorm(1-PCRIT/2)
ALPHA = PCRIT
setwd("Z:/")
date()
# ======================================================================================================================== #
# 2021-Jul-08 ENDES vs SIEN (agregado)
# Resultados
load(file="SIENVS.rda")
GRAF=list()
# Figura 1
x=wEVSS%>%filter(CDPTO=="PE")%>%mutate(MOE=ZCRIT*SDTE5E)
y=xEPPR%>%mutate(PERIO=as.numeric(Tramo),MOE=ZCRIT*SDTE5E)%>%filter(Categ=="Total")
g=
	ggplot(data=x%>%filter(FUENT=="SIEN"))+
	annotate(geom="text",x=2021,y=0.125,label="ENDES",color="darkblue",size=3.0)+
	annotate(geom="text",x=2021,y=0.175,label="SIEN",color="purple",size=3.0)+
	annotate(geom="text",x=2021,y=0.165,label="HIS",color="darkgreen",size=3.0)+
	geom_errorbar(mapping=aes(x=PERIO,ymin=PDTE5E-MOE,ymax=PDTE5E+MOE),color="darkblue",size=1,width=0.1,data=y)+
	geom_line(mapping=aes(x=PERIO,y=PDTE5E),color="darkblue",size=1,data=y)+
	geom_line(mapping=aes(x=PERIO,y=PDTE5),color="purple",size=1,data=x%>%filter(FUENT=="SIEN"))+
	geom_line(mapping=aes(x=PERIO,y=PDTE5),color="darkgreen",size=1,data=x%>%filter(FUENT=="HIS"))+
	scale_y_continuous(name="Prevalencia (/1)",limits=c(0,0.4))+
	scale_x_continuous(name="Año",limits=c(2008,2021),breaks=seq(2005,2020,5))+
	labs(title="Fig. 1",subtitle="Talla-Edad<-2z Perú 0-59m",caption="INEI/DTDIS & INS/DENAN/DEVAN")+
	theme_minimal()
GRAF[[1]]=g
# Figura 2
x=
	wEVSS%>%
	mutate(
		MOE=ZCRIT*SDTE5E,
		GEO=ifelse(CDPTO=="PE","nacional","regional")
	)
r=lm(formula=PDTE5~PDTE5E,data=drop_na(select(x,PDTE5,PDTE5E)));l=confint(r);s=summary(r)
m=lm(formula=PDTE5~poly(PDTE5E,3),data=drop_na(select(x,PDTE5,PDTE5E)))
y=tibble(PDTE5E=seq(0,0.35,0.025))
y=bind_cols(y,predict(object=m,newdata=y,se.fit=TRUE))%>%mutate(moe=ZCRIT*se.fit)
g=
	ggplot(data=x%>%filter(FUENT=="SIEN"))+
	geom_abline(intercept=0,slope=1,color="black")+
	geom_line(mapping=aes(x=PDTE5E,y=fit),linetype="dashed",data=y)+
	geom_ribbon(mapping=aes(x=PDTE5E,ymin=fit-moe,ymax=fit+moe),alpha=0.25,data=y)+
	geom_smooth(mapping=aes(x=PDTE5E,y=PDTE5),formula=y~x,method="lm",se=FALSE,color="orange",linetype="dotted")+
	annotate(geom="label",x=0.400,y=0.400,label="identidad",color="black",size=2.75)+
	annotate(
		geom="label",x=0.150,y=0.350,color="orange",size=2.75,
		label=
			paste0(
				"lineal",
				" a=",round(s$coefficients[1,1],2),
				"[IC:",round(l[1,1],2),",",round(l[1,2],2),"]",
				" b=",round(s$coefficients[2,1],2),
				"[IC:",round(l[2,1],2),",",round(l[2,2],2),"]",
				" R=",round(sqrt(s$adj.r.squared),2)
			)
	)+
	annotate(geom="label",x=0.375,y=0.325,label="cúbica",color="gray",size=2.75)+
	geom_point(mapping=aes(x=PDTE5E,y=PDTE5,shape=GEO,color=FUENT),size=1.5,data=x)+
	scale_y_continuous(name="Prev. HIS/SIEN (/1)",limits=c(0,0.4))+
	scale_x_continuous(name="Prev. ENDES (/1)",limits=c(0,0.4))+
	scale_shape_manual(name="Ámbito",values=c("nacional"="circle","regional"="circle open"))+
	scale_color_manual(name="Fuente",values=c("HIS"="green","SIEN"="darkblue"))+
	labs(
		title="Fig. 2",subtitle="Talla-Edad<-2z Perú 0-59m",
		caption="INEI & MINSA/INS"
	)+
	theme_minimal()+
	theme(legend.position=c(0.8,0.3))
GRAF[[2]]=g
# Figura 3
x=
	bind_rows(
		rSMED%>%mutate(PY=PSIX,GEO="R2")%>%select(PEND,PY,GEO,NEND),
		rSMED%>%mutate(PY=PSIE,GEO="R1")%>%select(PEND,PY,GEO,NEND),
		xSMED%>%ungroup()%>%mutate(PY=PSIE,GEO="N0",NEND=17341)%>%select(PEND,PY,GEO,NEND)
	)
g=
	ggplot(data=x)+
	geom_abline(intercept=0,slope=1,color="black")+
	annotate(geom="label",x=0.400,y=0.400,label="identidad",color="black",size=2.75)+
	geom_point(aes(x=PEND,y=PY,color=GEO),shape="circle open",alpha=0.5)+
	scale_y_continuous(name="Prev. 'HIS/SIEN' (/1)",limits=c(0,0.4))+
	scale_x_continuous(name="Prev. 'ENDES' (/1)",limits=c(0,0.4))+
	labs(title="Fig. 3",subtitle="Talla-Edad<-2z Perú 0-59m",caption="Simulación Monte Carlo")+
	scale_color_manual(name="Escenario",values=c("N0"="red","R1"="brown","R2"="pink"),labels=c("nacional","regional S=E=1","regional S,E<1"))+
	theme_minimal()+
	theme(legend.position=c(0.8,0.3))
GRAF[[3]]=g
# Salidas
T0="2021090519"
png(filename=paste0("GH","%01d",T0,".png"),width=1600,height=1600,units="px",res=300,pointsize=10)
for(g in GRAF){print(g)}
dev.off()
# ======================================================================================================================== #
